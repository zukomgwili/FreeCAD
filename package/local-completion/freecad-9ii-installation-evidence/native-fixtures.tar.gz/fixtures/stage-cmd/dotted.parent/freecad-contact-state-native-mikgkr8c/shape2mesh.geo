// geo file for meshing with Gmsh meshing software created by FreeCAD

// enable multi-core processing
General.NumThreads = 8;

// no result views required for adaptive meshing
// open brep geometry
Merge "Geometry_Geometry.brep";

// group data
For i In {1:24 }
	Physical Line(Sprintf("Edge%g", i), 0+i) = {i};
EndFor
For i In {1:12 }
	Physical Surface(Sprintf("Face%g", i), 24+i) = {i};
EndFor
For i In {1:2 }
	Physical Volume(Sprintf("Solid%g", i), 36+i) = {i};
EndFor
For i In {1:16 }
	Physical Point(Sprintf("Vertex%g", i), 38+i) = {i};
EndFor

// no size field based refinement
// no boundary layer settings for this mesh
// no transfinite refinements
// min, max Characteristic Length
Mesh.MeshSizeMax = 0.5;
Mesh.MeshSizeMin = 0.5;
Mesh.MeshSizeFromCurvature = 12; // number of elements per 2*pi radians, 0 to deactivate
Mesh.MeshSizeFromPoints = 0;

// optimize the mesh
Mesh.Optimize = 1;
Mesh.OptimizeNetgen = 0;
// High-order meshes optimization (0=none, 1=optimization, 2=elastic+optimization, 3=elastic, 4=fast curving)
Mesh.HighOrderOptimize = 0;

// mesh order and supported elements
Mesh.ElementOrder = 1;
Mesh.SecondOrderIncomplete = 1;

// mesh algorithm, only a few algorithms are usable with 3D boundary layer generation
// 2D mesh algorithm (1=MeshAdapt, 2=Automatic, 5=Delaunay, 6=Frontal, 7=BAMG, 8=DelQuad, 9=Packing Parallelograms, 11=Quasi-structured Quad)
Mesh.Algorithm = 2;
// 3D mesh algorithm (1=Delaunay, 2=New Delaunay, 4=Frontal, 7=MMG3D, 9=R-tree, 10=HTX)
Mesh.Algorithm3D = 1;

// subdivision algorithm
Mesh.SubdivisionAlgorithm = 0;

// meshing
Mesh  3;

// save
// Ignore Physical definitions and save all elements;
Mesh.SaveAll = 1;
Save "Geometry_Mesh.vtk";


// **********************************************************************
// Gmsh documentation:
// https://gmsh.info/doc/texinfo/gmsh.html#Mesh
//
// We do not check if something went wrong, like negative jacobians etc. You can run Gmsh manually yourself: 
//
// to see full Gmsh log, run in bash:
// /Users/zukomgwili/src/FreeCAD/.pixi/envs/default/bin/gmsh - /private/tmp/freecad-9ii-install-frvQG620/stage-cmd/dotted.parent/freecad-contact-state-native-mikgkr8c/shape2mesh.geo
//
// to run Gmsh and keep file in Gmsh GUI (with log), run in bash:
// /Users/zukomgwili/src/FreeCAD/.pixi/envs/default/bin/gmsh /private/tmp/freecad-9ii-install-frvQG620/stage-cmd/dotted.parent/freecad-contact-state-native-mikgkr8c/shape2mesh.geo
