# SPDX-License-Identifier: LGPL-2.1-or-later

# ***************************************************************************
# *                                                                         *
# *   Copyright (c) 2016 Bernd Hahnebach <bernd@bimstatik.org>              *
# *                                                                         *
# *   This program is free software; you can redistribute it and/or modify  *
# *   it under the terms of the GNU Lesser General Public License (LGPL)    *
# *   as published by the Free Software Foundation; either version 2 of     *
# *   the License, or (at your option) any later version.                   *
# *   for detail see the LICENCE text file.                                 *
# *                                                                         *
# *   This program is distributed in the hope that it will be useful,       *
# *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
# *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
# *   GNU Library General Public License for more details.                  *
# *                                                                         *
# *   You should have received a copy of the GNU Library General Public     *
# *   License along with this program; if not, write to the Free Software   *
# *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  *
# *   USA                                                                   *
# *                                                                         *
# ***************************************************************************

__title__ = "Tools for the work with finite element meshes"
__author__ = "Bernd Hahnebach"
__url__ = "https://www.freecad.org"

## \addtogroup FEM
#  @{

import hashlib
import json
import re
from types import SimpleNamespace

import numpy as np

import FreeCAD

from femtools import geomtools


# ************************************************************************************************
def get_femnodes_by_femobj_with_references(femmesh, femobj, mesh_object=None):
    obj = femobj["Object"]
    if obj.isDerivedFrom("Fem::ConstraintRigidBody"):
        return get_femnodes_by_owned_references(femmesh, obj, mesh_object)
    node_set = []
    if femmesh.GroupCount:
        node_set = get_femmesh_groupdata_sets_by_name(femmesh, femobj, "Node")
        # FreeCAD.Console.PrintMessage("node_set_group: {}\n".format(node_set))
        if node_set:
            FreeCAD.Console.PrintLog(
                "    Finite element mesh nodes where retrieved "
                "from existent finite element mesh group data.\n"
            )
    if not node_set:
        FreeCAD.Console.PrintLog(
            "    Finite element mesh nodes will be retrieved "
            "by searching the appropriate nodes in the finite element mesh.\n"
        )
        node_set = get_femnodes_by_references(femmesh, femobj["Object"].References)
        # FreeCAD.Console.PrintMessage("node_set_nogroup: {}\n".format(node_set))

    # use set for node sets to be sure all nodes are unique
    # use sorted to be sure the order is the same on different runs
    # be aware a sorted set returns a list, because set are not sorted by default
    return sorted(set(node_set))


def get_mesh_geometry_signature(part, *, canonical=True):
    """Native global BRep and input-link ownership, not lazily populated names.

    A native BRep read normalizes cached topology flags and signed-zero frames.
    It does not round coordinates or relax geometry membership. The legacy raw
    representation remains available for exact comparison with existing meshes.
    """
    shape = part.Shape.copy()
    if hasattr(part, "getGlobalPlacement"):
        shape.Placement = part.getGlobalPlacement()
    shape.isValid()  # Normalize native check state on the copy, not the source.
    brep = shape.exportBrepToString()
    if canonical:
        import Part

        restored = Part.Shape()
        restored.importBrepFromString(brep, False)
        restored.isValid()
        brep = restored.exportBrepToString()
    graph = {}

    def encode(value):
        if hasattr(value, "Document") and hasattr(value, "Name"):
            if value.Document != part.Document and not value.Document.FileName:
                raise ValueError(
                    "Save external geometry documents before generating mesh ownership.")
            key = ("local" if value.Document == part.Document else value.Document.FileName,
                   value.Name)
            if key not in graph:
                graph[key] = {}  # Mark before following potentially shared links.
                graph[key].update({name: encode(value.getPropertyByName(name))
                                   for name in sorted(value.PropertiesList)
                                   if "Link" in value.getTypeIdOfProperty(name)})
            return key
        if isinstance(value, (list, tuple)):
            return [encode(item) for item in value]
        return value

    encode(part)
    data = [brep, sorted(graph.items())]
    return hashlib.sha256(json.dumps(data).encode("utf-8")).hexdigest()


def mesh_geometry_matches(mesh_object, part):
    """Accept only an exact current or legacy native ownership fingerprint."""
    signature = getattr(mesh_object, "ElementGroupGeometry", "")
    return bool(signature) and (
        signature == get_mesh_geometry_signature(part)
        or signature == get_mesh_geometry_signature(part, canonical=False)
    )


def _same_occurrence_geometry(first, second):
    """Compare full kernel geometry after native history, not only vertices/COM.

    A closed curve can have one seam vertex shared with a different curve.
    Common length/area/volume must cover both candidates at kernel precision.
    This only discriminates native-history occurrences; it cannot create one.
    """
    if first.ShapeType != second.ShapeType:
        return False
    if first.isSame(second):
        return True
    precision = FreeCAD.Base.Precision.confusion()
    if first.ShapeType == "Vertex":
        return (first.Point - second.Point).Length <= precision
    dimension = {"Edge": 1, "Face": 2, "Solid": 3}.get(first.ShapeType)
    if dimension is None:
        return False
    measure = {1: "Length", 2: "Area", 3: "Volume"}[dimension]
    left, right = getattr(first, measure), getattr(second, measure)
    scale = max(1., first.BoundBox.DiagonalLength, second.BoundBox.DiagonalLength)
    tolerance = precision * scale ** (dimension - 1)
    if min(left, right) <= tolerance or abs(left - right) > tolerance:
        return False
    common = getattr(first.common(second), measure)
    return abs(common - left) <= tolerance and abs(common - right) <= tolerance


def get_femnodes_by_owned_references(femmesh, obj, mesh_object=None):
    """Resolve current region references using owned mesh connectivity.

    Coordinates may validate a result, but cannot distinguish independent
    coincident mesh owners. Never use cached analysis aggregate groups here.
    The optional mesh object keeps the historic two-argument API usable for a
    constraint in an analysis with one mesh, while writers pass it explicitly.
    """
    return _get_mesh_region_by_owned_references(femmesh, obj, mesh_object)[0]


def _get_mesh_region_by_owned_references(femmesh, obj, mesh_object, context=None):
    """Return validated nodes and current CAD entity-to-native-group members.

    Legacy meshes have no entity provenance and return None for the groups.
    Keep entity connectivity available: a union of owned nodes alone cannot
    establish that a volume facet belongs to one of the selected CAD faces.
    """
    if mesh_object is None:
        meshes = {
            member
            for parent in obj.InList
            if parent.isDerivedFrom("Fem::FemAnalysis")
            for member in parent.Group
            if member.isDerivedFrom("Fem::FemMeshObject")
        }
        if len(meshes) > 1:
            raise ValueError(f"{obj.Name}: ambiguous mesh ownership; specify the mesh object.")
        mesh_object = next(iter(meshes), None)
    part = getattr(mesh_object, "Shape", None)
    original = list(getattr(mesh_object, "ElementGroupNames", []))
    references = [
        (owner, name)
        for owner, names in getattr(mesh_object, "ElementGroupReferences", [])
        for name in names
    ]
    signature = getattr(mesh_object, "ElementGroupGeometry", "")
    if not part:
        if original or references or signature:
            raise ValueError(f"{obj.Name}: missing mesh geometry owner; regenerate the mesh.")
        return sorted(get_femnodes_by_references(femmesh, obj.References)), None

    for owner, names in obj.References:
        if owner is None or not names:
            raise ValueError(f"{obj.Name}: unresolved region references.")
        for name in names:
            if not name:
                continue  # Whole shape references are supported by native RBEs.
            _, mapped, indexed = owner.resolveSubElement(name)
            if not mapped and (
                ";" in name
                or re.fullmatch(r"(?:Vertex|Edge|Face|Solid)[1-9][0-9]*", indexed) is None
            ):
                raise ValueError(f"{obj.Name}: unresolved region {owner.Name}.{name}.")
            shape = owner.getSubObject(name)
            if shape is None or not hasattr(shape, "isNull") or shape.isNull():
                raise ValueError(f"{obj.Name}: unresolved region {owner.Name}.{name}.")

    if original or references or signature:
        if context is None:
            if not mesh_geometry_matches(mesh_object, part):
                raise ValueError(f"{obj.Name}: changed mesh geometry; regenerate the mesh.")
            own_mesh = mesh_object.FemMesh
            ids = femmesh.getIdByElementType("All")
            if (
                femmesh.Nodes != own_mesh.Nodes
                or ids != own_mesh.getIdByElementType("All")
                or any(femmesh.getElementNodes(e) != own_mesh.getElementNodes(e) for e in ids)
            ):
                raise ValueError(f"{obj.Name}: supplied mesh does not match its geometry owner.")

            def group_data(mesh):
                return sorted(
                    (mesh.getGroupName(g), mesh.getGroupElementType(g), mesh.getGroupElements(g))
                    for g in mesh.Groups
                )

            if group_data(femmesh) != group_data(own_mesh):
                raise ValueError(
                    f"{obj.Name}: supplied mesh groups do not match their geometry owner."
                )
        elif context.femmesh is not femmesh or context.mesh_object != mesh_object:
            raise ValueError(f"{obj.Name}: invalid mesh ownership context.")
        wanted = []
        for owner, names in obj.References:
            for name in names:
                selected = owner.getSubObject(name)
                expected = len(selected.Solids) if selected.ShapeType == "Compound" else 1
                current = get_reference_group_elements(
                    SimpleNamespace(Name=obj.Name, References=[(owner, [name])]), part
                )[1]
                if not current or len(current) != expected:
                    raise ValueError(f"{obj.Name}: current reference is absent from mesh geometry.")
                wanted.extend(current)
        if len(original) != len(references) or len(original) != len(set(original)):
            raise ValueError(f"{obj.Name}: invalid mesh group provenance; regenerate the mesh.")
        if context is None:
            current_groups = {}
            for old, (owner, name) in zip(original, references):
                if owner != part:
                    raise ValueError(f"{obj.Name}: changed mesh geometry; regenerate the mesh.")
                current_groups.setdefault(name, []).append(old)
            groups = {}
            for group in femmesh.Groups:
                groups.setdefault(femmesh.getGroupName(group), []).append(group)
        else:
            current_groups, groups = context.current_groups, context.group_ids
        result = set()
        entity_sets = {}
        for name in wanted:
            if context is not None and name in context.regions:
                nodes, members = context.regions[name]
                result.update(nodes)
                entity_sets[name] = members
                continue
            matches = current_groups.get(name, [])
            if len(matches) != 1 or len(groups.get(matches[0], [])) != 1:
                raise ValueError(f"{obj.Name}: missing or ambiguous mesh group for {name}; remesh.")
            group = groups[matches[0]][0]
            members = (
                femmesh.getGroupElements(group) if context is None else context.groups[group][2]
            )
            if not members:
                raise ValueError(f"{obj.Name}: empty mesh group for {name}; remesh.")
            kind = (
                femmesh.getGroupElementType(group) if context is None else context.groups[group][1]
            )
            if kind == "Node" and not name.startswith("Vertex"):
                raise ValueError(f"{obj.Name}: wrong mesh group type for {name}; remesh.")
            if kind == "Node":
                nodes = set(members)
            else:
                expected_type = next(
                    (
                        prefix
                        for prefix in ("Face", "Edge", "Solid", "Vertex")
                        if name.startswith(prefix)
                    ),
                    None,
                )
                allowed_kind = {
                    "Face": "Face",
                    "Edge": "Edge",
                    "Solid": "Volume",
                    "Vertex": "0DElement",
                }.get(expected_type)
                if kind not in ("All", allowed_kind):
                    raise ValueError(f"{obj.Name}: wrong mesh group type for {name}; remesh.")
                entities = (
                    context.faces
                    if context is not None and expected_type == "Face"
                    else {
                        "Face": femmesh.Faces,
                        "Edge": femmesh.Edges,
                        "Solid": femmesh.Volumes,
                        "Vertex": femmesh.getIdByElementType("0DElement"),
                    }.get(expected_type)
                )
                if entities is not None and not set(members).issubset(entities):
                    raise ValueError(f"{obj.Name}: invalid mesh connectivity for {name}; remesh.")
                nodes = {
                    node
                    for element in members
                    for node in (
                        femmesh.getElementNodes(element)
                        if context is None
                        else context.elements[element]
                    )
                }
            # Validate, never repair/filter, against the current positioned CAD
            # entity. This rejects movement without a remesh, retaining owner IDs.
            if not _owned_nodes_fit_region(
                femmesh, part, name, nodes, context.nodes if context is not None else None
            ):
                region = part.getSubObject(name)
                if (
                    getattr(mesh_object, "ElementOrder", "") == "2nd"
                    and getattr(mesh_object, "SecondOrderLinear", False)
                    and region.ShapeType == "Face"
                    and region.findPlane() is None
                ):
                    raise ValueError(
                        f"{obj.Name}: SecondOrderLinear cannot establish exact curved face "
                        f"ownership for {name}; disable SecondOrderLinear and regenerate "
                        "the mesh, or qualify a first-order mesh."
                    )
                raise ValueError(f"{obj.Name}: stale mesh for current {name}; regenerate the mesh.")
            if context is not None:
                context.regions[name] = frozenset(nodes), tuple(members)
            result.update(nodes)
            entity_sets[name] = tuple(members)
        return sorted(result), entity_sets

    # Ungrouped/imported meshes retain the existing unambiguous geometric route.
    # With coincident CAD entities, however, it cannot establish ownership.
    for owner, names in obj.References:
        for name in names:
            selected = sub_shape_at_global_placement(owner, name)
            shapes = selected.Solids if selected.ShapeType == "Compound" else [selected]
            for shape in shapes:
                candidates = {
                    "Face": part.Shape.Faces,
                    "Edge": part.Shape.Edges,
                    "Solid": part.Shape.Solids,
                    "Vertex": part.Shape.Vertexes,
                }[shape.ShapeType]
                if sum(_same_occurrence_geometry(shape, other) for other in candidates) > 1:
                    raise ValueError(
                        f"{obj.Name}: coincident regions need owned mesh groups; remesh."
                    )
    return sorted(get_femnodes_by_references(femmesh, obj.References)), None


def _owned_nodes_fit_region(femmesh, part, name, nodes, coordinates=None):
    """Validate every owned node with the native classifier, not every mesh node.

    This temporary point cloud is only a geometry check, never an export mesh.
    getNodeById applies the original mesh transform; compact temporary IDs avoid
    allocating sparse mesh storage. Native CAD tolerances remain unchanged.
    """
    import Fem

    if not nodes:
        return False
    candidates = Fem.FemMesh()
    for index, node in enumerate(sorted(nodes), 1):
        point = femmesh.getNodeById(node) if coordinates is None else coordinates[node]
        candidates.addNode(point.x, point.y, point.z, index)
    current = get_femnodes_by_refshape(candidates, (part, [name]))
    return len(set(current)) == len(nodes)


# ************************************************************************************************
def get_femelements_by_references(femmesh, femelement_table, references, femnodes_ele_table=None):
    """get the femelements for a list of references"""
    references_femelements = []
    for ref in references:
        # femnodes for the current ref
        ref_femnodes = get_femnodes_by_refshape(femmesh, ref)
        if femnodes_ele_table:
            # blind fast binary search, works for volumes only
            # femelements for all references
            references_femelements += get_femelements_by_femnodes_bin(
                femelement_table, femnodes_ele_table, ref_femnodes
            )
        else:
            # standard search
            # femelements for all references
            references_femelements += get_femelements_by_femnodes_std(
                femelement_table, ref_femnodes
            )
    return references_femelements


# ************************************************************************************************
def get_femnodes_by_references(femmesh, references):
    """get the femnodes for a list of references"""
    references_femnodes = []
    for ref in references:
        references_femnodes += get_femnodes_by_refshape(femmesh, ref)

    # return references_femnodes  # keeps duplicate nodes, keeps node order

    # if nodes are used for nodesets, duplicates should be removed
    return list(set(references_femnodes))  # removes duplicate nodes, sorts node order


def get_femnodes_by_refshape(femmesh, ref):
    nodes = []
    for refelement in ref[1]:
        r = sub_shape_at_global_placement(ref[0], refelement)
        FreeCAD.Console.PrintMessage(
            "    "
            "ReferenceShape ... Type: {}, "
            "Object name: {}, "
            "Object label: {}, "
            "Element name: {}\n".format(r.ShapeType, ref[0].Name, ref[0].Label, refelement)
        )
        if r.ShapeType == "Vertex":
            nodes += femmesh.getNodesByVertex(r)
        elif r.ShapeType == "Edge":
            nodes += femmesh.getNodesByEdge(r)
        elif r.ShapeType == "Face":
            nodes += femmesh.getNodesByFace(r)
        elif r.ShapeType == "Solid":
            nodes += femmesh.getNodesBySolid(r)
        elif r.ShapeType == "Compound":
            for s in r.Solids:
                nodes += femmesh.getNodesBySolid(s)
        else:
            FreeCAD.Console.PrintMessage("  No Vertice, Edge, Face or Solid as reference shapes!\n")
    return nodes


# ************************************************************************************************
def get_femelement_table(femmesh):
    """get_femelement_table(femmesh): { elementid : [ nodeid, nodeid, ... , nodeid ] }"""
    femelement_table = {}
    if is_solid_femmesh(femmesh):
        for i in femmesh.Volumes:
            femelement_table[i] = femmesh.getElementNodes(i)
    elif is_face_femmesh(femmesh):
        for i in femmesh.Faces:
            femelement_table[i] = femmesh.getElementNodes(i)
    elif is_edge_femmesh(femmesh):
        for i in femmesh.Edges:
            femelement_table[i] = femmesh.getElementNodes(i)
    else:
        FreeCAD.Console.PrintError("Neither solid nor face nor edge femmesh!\n")
    return femelement_table


# ************************************************************************************************
def get_femelement_volumes_table(femmesh):
    """get_femelement_volumes_table(femmesh): { elementid : [ nodeid, nodeid, ... , nodeid ] }"""
    table = {}
    for i in femmesh.Volumes:
        table[i] = femmesh.getElementNodes(i)
    return table


# ************************************************************************************************
def get_femelement_faces_table(femmesh, faces_only=None):
    """get_femelement_faces_table(femmesh): { elementid : [ nodeid, nodeid, ... , nodeid ] }"""
    table = {}
    if not faces_only:
        faces_only = femmesh.FacesOnly
    for i in faces_only:
        table[i] = femmesh.getElementNodes(i)
    return table


# ************************************************************************************************
def get_femelement_edges_table(femmesh, edges_only=None):
    """get_femelement_edges_table(femmesh): { elementid : [ nodeid, nodeid, ... , nodeid ] }"""
    table = {}
    if not edges_only:
        edges_only = femmesh.EdgesOnly
    for i in edges_only:
        table[i] = femmesh.getElementNodes(i)
    return table


# ************************************************************************************************
def get_femnodes_ele_table(femnodes_mesh, femelement_table):
    """the femnodes_ele_table contains for each node its membership in elements
    {nodeID : [[eleID, NodePosition], [], ...], nodeID : [[], [], ...], ...}
    stored information is:
    element number, the number of nodes per element
    the position of the node in the element.
    The position of the node in the element is coded
    as a set bit at that position in a bit array (integer)
    FIXME: the number of nodes per element should be
    replaced by the type of the element
    but I did not know how to get this from the mesh.
    Since the femelement_table contains either
    volume or face or edgemesh the femnodes_ele_table only
    has either volume or face or edge elements
    see get_femelement_table()
    """
    femnodes_ele_table = {}  # node_dict in ulrichs class
    for n in femnodes_mesh:  # initialize it with sorted node keys and empty lists
        femnodes_ele_table[n] = []
    for ele in femelement_table:
        ele_list = femelement_table[ele]
        pos = int(1)
        for ele_node in ele_list:
            femnodes_ele_table[ele_node].append([ele, pos])
            pos = pos << 1
    return femnodes_ele_table


# ************************************************************************************************
def get_copy_of_empty_femelement_table(femelement_table):
    """{eleID : 0, eleID : 0, ...}"""
    empty_femelement_table = {}
    for ele in femelement_table:  # initialize it with sorted element keys and empty int
        empty_femelement_table[ele] = 0
    return empty_femelement_table.copy()


# ************************************************************************************************
def get_bit_pattern_dict(femelement_table, femnodes_ele_table, node_set):
    """Now we are looking for nodes inside of the Faces = filling the bit_pattern_dict
    {eleID : [lenEleNodes, binary_position]}
    see forum post for a very good explanation of what"s really happening
    https://forum.freecad.org/viewtopic.php?f=18&t=17318&start=50#p141108
    The bit_pattern_dict holds later an integer (bit array) for each element, which gives us
    the information we are searching for:
    Is this element part of the node list (searching for elements)
    or has this element a face we are searching for?
    The number in the ele_dict is organized as a bit array.
    The corresponding bit is set, if the node of the node_set is contained in the element.
    """
    bit_pattern_dict = get_copy_of_empty_femelement_table(femelement_table)
    # # initializing the bit_pattern_dict
    for ele in femelement_table:
        len_ele = len(femelement_table[ele])
        bit_pattern_dict[ele] = [len_ele, 0]
    for node in node_set:
        for nList in femnodes_ele_table[node]:
            bit_pattern_dict[nList[0]][1] += nList[1]
    return bit_pattern_dict


# ************************************************************************************************
def get_element_volumes_elements_from_binary_search(bit_pattern_dict):
    """get volume element by coincident nodes"""
    mask_tetra10 = {0b1111111111: 1}
    mask_tetra4 = {0b1111: 1}
    mask_hexa8 = {0b11111111: 1}
    mask_hexa20 = {0b11111111111111111111: 1}
    mask_penta6 = {0b111111: 1}
    mask_penta15 = {0b111111111111111: 1}
    vol_dict = {
        4: mask_tetra4,
        6: mask_penta6,
        8: mask_hexa8,
        10: mask_tetra10,
        15: mask_penta15,
        20: mask_hexa20,
    }
    volumes = []
    for ele in bit_pattern_dict:
        mask_dict = vol_dict[bit_pattern_dict[ele][0]]
        for key in mask_dict:
            if (key & bit_pattern_dict[ele][1]) == key:
                volumes.append(ele)
    return volumes


def get_element_faces_elements_from_binary_search(bit_pattern_dict):
    """get face element by coincident nodes"""
    mask_tria3 = {0b111: 1}
    mask_tria6 = {0b111111: 1}
    mask_quad4 = {0b1111: 1}
    mask_quad8 = {0b11111111: 1}
    vol_dict = {
        3: mask_tria3,
        6: mask_tria6,
        4: mask_quad4,
        8: mask_quad8,
    }
    faces = []
    for ele in bit_pattern_dict:
        mask_dict = vol_dict[bit_pattern_dict[ele][0]]
        for key in mask_dict:
            if (key & bit_pattern_dict[ele][1]) == key:
                faces.append(ele)
    return faces


def get_element_edges_elements_from_binary_search(bit_pattern_dict):
    """get edge element by coincident nodes"""
    mask_seg2 = {0b11: 1}
    mask_seg3 = {0b111: 1}
    vol_dict = {
        2: mask_seg2,
        3: mask_seg3,
    }
    edges = []
    for ele in bit_pattern_dict:
        mask_dict = vol_dict[bit_pattern_dict[ele][0]]
        for key in mask_dict:
            if (key & bit_pattern_dict[ele][1]) == key:
                edges.append(ele)
    return edges


def get_element_edges_from_binary_search(
    bit_pattern_dict, mask_tria3={}, mask_tria6={}, mask_quad4={}, mask_quad8={}
):
    """get face element edges by coincident nodes"""
    vol_dict = {
        3: mask_tria3,
        4: mask_quad4,
        6: mask_tria6,
        8: mask_quad8,
    }
    edges = []
    for ele in bit_pattern_dict:
        mask_dict = vol_dict[bit_pattern_dict[ele][0]]
        for key in mask_dict:
            if (key & bit_pattern_dict[ele][1]) == key:
                edges.append([ele, mask_dict[key]])

    return edges


def get_element_faces_from_binary_search(
    bit_pattern_dict,
    mask_tetra4={},
    mask_tetra10={},
    mask_hexa8={},
    mask_hexa20={},
    mask_penta6={},
    mask_penta15={},
):
    """get volume element faces by coincident nodes"""
    # the forum topic discussion with ulrich1a and others ... Better mesh last instead of mesh first
    # https://forum.freecad.org/viewtopic.php?f=18&t=17318#p137171
    # https://forum.freecad.org/viewtopic.php?f=18&t=17318&start=60#p141484
    # https://forum.freecad.org/viewtopic.php?f=18&t=17318&start=50#p141108
    # https://forum.freecad.org/viewtopic.php?f=18&t=17318&start=40#p140371
    vol_dict = {
        4: mask_tetra4,
        6: mask_penta6,
        8: mask_hexa8,
        10: mask_tetra10,
        15: mask_penta15,
        20: mask_hexa20,
    }
    faces = []
    for ele in bit_pattern_dict:
        mask_dict = vol_dict[bit_pattern_dict[ele][0]]
        for key in mask_dict:
            if (key & bit_pattern_dict[ele][1]) == key:
                faces.append([ele, mask_dict[key]])
    return faces


# ************************************************************************************************
def get_femelements_by_femnodes_bin(femelement_table, femnodes_ele_table, node_list):
    """for every femelement of femelement_table
    if all nodes of the femelement are in node_list,
    the femelement is added to the list which is returned
    blind fast binary search, but works for volumes only
    """
    FreeCAD.Console.PrintMessage("binary search: get_femelements_by_femnodes_bin\n")
    vol_masks = {4: 15, 6: 63, 8: 255, 10: 1023, 15: 32767, 20: 1048575}
    # Now we are looking for nodes inside of the Volumes = filling the bit_pattern_dict
    bit_pattern_dict = get_bit_pattern_dict(femelement_table, femnodes_ele_table, node_list)
    # search
    ele_list = []  # The ele_list contains the result of the search.
    for ele in bit_pattern_dict:
        if bit_pattern_dict[ele][1] == vol_masks[bit_pattern_dict[ele][0]]:
            ele_list.append(ele)
    return ele_list


# ************************************************************************************************
def get_femelements_by_femnodes_std(femelement_table, node_list):
    """for every femelement of femelement_table
    if all nodes of the femelement are in node_list,
    the femelement is added to the list which is returned
    e: elementlist
    nodes: nodelist"""
    FreeCAD.Console.PrintMessage("std search: get_femelements_by_femnodes_std\n")
    e = []  # elementlist
    for elementID in sorted(femelement_table):
        nodecount = 0
        for nodeID in femelement_table[elementID]:
            if nodeID in node_list:
                nodecount = nodecount + 1
        # all nodes of the element are in the node_list!
        if nodecount == len(femelement_table[elementID]):
            e.append(elementID)
    return e


def get_femvolumeelements_by_femfacenodes(femelement_table, node_list):
    """assume femelement_table only has volume elements
    for every femvolumeelement of femelement_table
    for tetra4 and tetra10 the C++ methods could be used --> test again to be sure
    if hexa8 volume element
        --> if exact 4 element nodes are in node_list --> add femelement
    if hexa20 volume element
        --> if exact 8 element nodes are in node_list --> add femelement
    if penta6 volume element
        --> if exact 3 or 6 element nodes are in node_list --> add femelement
    if penta15 volume element
        --> if exact 6 or 8 element nodes are in node_list --> add femelement
    e: elementlist
    nodes: nodelist"""
    e = []  # elementlist
    for elementID in sorted(femelement_table):
        nodecount = 0
        el_nd_ct = len(femelement_table[elementID])
        if el_nd_ct == 4:  # tetra4
            for nodeID in femelement_table[elementID]:
                if nodeID in node_list:
                    nodecount = nodecount + 1
            if nodecount == 3:
                e.append(elementID)
        elif el_nd_ct == 10:  # tetra10
            for nodeID in femelement_table[elementID]:
                if nodeID in node_list:
                    nodecount = nodecount + 1
            if nodecount == 4:
                e.append(elementID)
        elif el_nd_ct == 8:  # hexa8
            for nodeID in femelement_table[elementID]:
                if nodeID in node_list:
                    nodecount = nodecount + 1
            if nodecount == 4:
                e.append(elementID)
        elif el_nd_ct == 20:  # hexa20
            for nodeID in femelement_table[elementID]:
                if nodeID in node_list:
                    nodecount = nodecount + 1
            if nodecount == 8:
                e.append(elementID)
        elif el_nd_ct == 6:  # penta6
            for nodeID in femelement_table[elementID]:
                if nodeID in node_list:
                    nodecount = nodecount + 1
            if nodecount == 3 or nodecount == 4:
                e.append(elementID)
        elif el_nd_ct == 15:  # penta15
            for nodeID in femelement_table[elementID]:
                if nodeID in node_list:
                    nodecount = nodecount + 1
            if nodecount == 6 or nodecount == 8:
                e.append(elementID)
        else:
            FreeCAD.Console.PrintError(
                "Error in get_femvolumeelements_by_femfacenodes(): "
                "unknown volume element: {}\n".format(el_nd_ct)
            )
    # FreeCAD.Console.PrintMessage("{}\n".format(sorted(e)))
    return e


# ************************************************************************************************
def get_femelement_sets(femmesh, femelement_table, fem_objects, femnodes_ele_table=None):
    # fem_objects = FreeCAD FEM document objects
    # get femelements for reference shapes of each obj.References
    count_femelements = 0
    referenced_femelements = np.zeros((max(femelement_table.keys()) + 1,), dtype=int)
    has_remaining_femelements = None
    for fem_object_i, fem_object in enumerate(fem_objects):
        obj = fem_object["Object"]
        FreeCAD.Console.PrintMessage(
            "Constraint: {} --> We're going to search "
            "in the mesh for the element ID's.\n".format(obj.Name)
        )
        # unique short identifier
        fem_object["ShortName"] = get_elset_short_name(obj, fem_object_i)
        if obj.References:
            ref_shape_femelements = []
            ref_shape_femelements = get_femelements_by_references(
                femmesh, femelement_table, obj.References, femnodes_ele_table
            )
            ref_shape_femelements_array = np.zeros_like(referenced_femelements)
            ref_shape_femelements_array[ref_shape_femelements] = 1
            referenced_femelements += ref_shape_femelements_array
            count_femelements += len(ref_shape_femelements)
            fem_object["FEMElements"] = ref_shape_femelements
        else:
            has_remaining_femelements = obj.Name
    # get remaining femelements for the fem_objects
    if has_remaining_femelements:
        femelement_table_array = np.zeros_like(referenced_femelements)
        femelement_table_array[list(femelement_table)] = 1
        remaining_femelements_array = femelement_table_array > referenced_femelements
        (non_zeros,) = remaining_femelements_array.nonzero()
        if non_zeros.size:
            remaining_femelements = [i.item() for i in np.nditer(non_zeros)]
        else:
            remaining_femelements = []
        count_femelements += len(remaining_femelements)
        for fem_object in fem_objects:
            obj = fem_object["Object"]
            if obj.Name == has_remaining_femelements:
                fem_object["FEMElements"] = sorted(remaining_femelements)
    # check if all worked out well
    if femelements_count_ok(len(femelement_table), count_femelements):
        return True
    else:
        FreeCAD.Console.PrintError(
            "Error in get_femelement_sets -- > femelements_count_ok() failed!\n"
        )
        return False


# ************************************************************************************************
def get_femelement_direction1D_set(femmesh, femelement_table, beamrotation_objects, theshape=None):
    """
    get for each geometry edge direction, the local direction m and the element ids and
    # write all into the beamrotation_objects
    means no return value, we're going to write into the beamrotation_objects dictionary
    FEMRotations1D is a list of dictionaries for every beamdirection of all edges
    beamrot_obj["FEMRotations1D"] = [{
        "ids" : [theids],
        "direction" : direction,
        "beam_axis_m" : beam_axis_m
    }, ... ]
    """
    if len(beamrotation_objects) == 0:
        # no beamrotation document object, all beams use standard rotation of 0 degree (angle)
        # we need theshape (the shape which was meshed)
        # since ccx needs to split them in sets anyway we need to take care of this too
        rotations_ids = get_femelement_directions_theshape(femmesh, femelement_table, theshape)
        # add normals for each direction
        rotation_angle = 0
        for rot in rotations_ids:
            rot["beam_axis_m"] = get_beam_main_axis_m(rot["direction"], rotation_angle)
        # key "Object" will be empty
        beamrotation_objects.append({"FEMRotations1D": rotations_ids, "ShortName": "Rstd"})
    elif len(beamrotation_objects) == 1:
        # one beamrotation document object with no references
        # all beams use rotation from this object
        # we need theshape (the shape which was meshed)
        # since ccx needs to split them in sets anyway we need to take care of this too
        rotations_ids = get_femelement_directions_theshape(femmesh, femelement_table, theshape)
        # add normals for each direction
        rotation_angle = beamrotation_objects[0]["Object"].Rotation.getValueAs("deg").Value
        for rot in rotations_ids:
            rot["beam_axis_m"] = get_beam_main_axis_m(rot["direction"], rotation_angle)
        beamrotation_objects[0]["FEMRotations1D"] = rotations_ids
        beamrotation_objects[0]["ShortName"] = "R0"
    elif len(beamrotation_objects) > 1:
        # multiple beam rotation document objects
        # rotations defined by reference shapes, TODO implement this
        # do not forget all the corner cases:
        # one beam rotation object, but not all edges are ref shapes
        # more than one beam rotation object, but not all edges are in the ref shapes
        # for the both cases above, all other edges get standard rotation.
        # more than one beam rotation objects and on has no ref shapes
        # all edges no in an rotation object use this rotation
        # one edge is in more than one beam rotation object, error
        # pre check, only one beam rotation with empty ref shapes is allowed
        # we need theshape for multiple rotations too
        # because of the corner cases mentioned above
        FreeCAD.Console.PrintError("Multiple Rotations not yet supported!\n")
    for rot_object in beamrotation_objects:  # debug output
        FreeCAD.Console.PrintMessage("{}\n".format(rot_object["FEMRotations1D"]))


# ************************************************************************************************
def get_femelement_directions_theshape(femmesh, femelement_table, theshape):
    # see get_femelement_direction1D_set
    rotations_ids = []
    # add directions and all ids for each direction
    for e in theshape.Shape.Edges:
        the_edge = {}
        the_edge["direction"] = e.Vertexes[1].Point - e.Vertexes[0].Point
        edge_femnodes = femmesh.getNodesByEdge(e)  # femnodes for the current edge
        # femelements for this edge
        the_edge["ids"] = get_femelements_by_femnodes_std(femelement_table, edge_femnodes)
        for rot in rotations_ids:
            # tolerance will be managed by FreeCAD
            # see https://forum.freecad.org/viewtopic.php?f=22&t=14179
            if rot["direction"] == the_edge["direction"]:
                rot["ids"] += the_edge["ids"]
                break
        else:
            rotations_ids.append(the_edge)
    return rotations_ids


# ************************************************************************************************
def get_beam_main_axis_m(beam_direction: FreeCAD.Vector, defined_angle: int) -> FreeCAD.Vector:

    # former name was get_beam_normal
    # see forum topic https://forum.freecad.org/viewtopic.php?f=18&t=24878
    # beam_direction ... FreeCAD vector
    # defined_angle ... degree
    # base for the rotation:
    # a beam_direction = (1, 0, 0) and angle = 0, returns (0, -1, 0)
    # changing the angle, changes the normal accordingly, 360 would again return (0, -1, 0)
    #
    # original thread discussing this (kept for history):
    #   https://forum.freecad.org/viewtopic.php?f=18&t=24878&start=30#p195567
    #   https://forum.freecad.org/viewtopic.php?f=13&t=59239&start=140#p521999
    # thread with updated analysis, that fixes a found bug:
    #   https://forum.freecad.org/viewtopic.php?t=85951
    #
    # CalculiX uses negative z axis as base, if nothing is given in input file
    # see the standard direction of 1-direction in CalxuliX manual
    # here the local main axis is called beam_axis_m the minor axis will be beam_axis_n
    # eventually a better name might be get_beam_rotation

    # FIXME: since we fix the base angle we would get this information out of the mesh edge too
    # upd: angle is not fixed anymore (?) (except for the vertical beam)
    print("beam_axis_m is retrieved from the geometry but we could get if from mesh edge too")
    # print("beam_direction: {}".format(beam_direction))
    # print("defined_angle: {}".format(defined_angle))

    import math

    def normalize(vec: FreeCAD.Vector) -> FreeCAD.Vector:
        return vec / vec.Length

    def get_normal(vec: FreeCAD.Vector) -> FreeCAD.Vector:
        x, y, z = vec

        if z == 0:  # in xy plane
            n = (0, 0, -1)  # default in CalculiX
        elif z != 0 and x == y == 0:  # vertical beam
            n = (-1, 0, 0)  # or (0, -1, 0)
        else:
            #             . (x, y, z)
            #            / \
            #       vec /   \ n
            #          /     \
            # (0,0,0) .-------. (x, y, ?)
            #
            # since `n` should be perpendicular to `vec`
            # calculate the dot product to find `?`
            n = (x, y, -(x**2 + y**2) / z)
        # we want the normal to point downwards for `vec` with
        # z < 0 as well
        n = normalize((1 | -(z > 0)) * FreeCAD.Vector(n))

        # sanity check
        dot = vec.dot(n)
        if not math.isclose(dot, 0, abs_tol=1e-13):
            FreeCAD.Console.PrintError(
                f"Wrong calculation of normal vector for {vec = }! {n = }, {dot = }\n"
                "Please consider submitting an issue\n"
            )

        return n

    def rotate_around_vector(axis: FreeCAD.Vector, angle: int) -> FreeCAD.Vector:
        """
        * - is the axis vector, which is looking at us
        the rotation is done counter-clockwise around this vector

        More info is available at:
        https://en.wikipedia.org/wiki/Rodrigues%27_rotation_formula
        """
        angle = math.radians(angle)
        axis = normalize(axis)
        n = get_normal(axis)
        # the mentioned formula rotates both the perpendicular and not parts of the vector
        # but since we're rotating a normal (which is already perpendicular), one can
        # simplify the formula a bit
        rot = n * math.cos(angle) + axis.cross(n) * math.sin(angle)
        # replace all the close-to-zero elements with 0 itself
        # I was getting values of 1e-17 order, hence the threshold is of 1e-15 order
        return FreeCAD.Vector([coord * (abs(coord) > 1e-15) for coord in rot])

    # `+90` here is because the normal is calculated towards -z axis
    # and we use 1,2-directions, that are rotated by `+90` degrees
    return rotate_around_vector(beam_direction, defined_angle + 90)


# ************************************************************************************************
def get_femmesh_groupdata_sets_by_name(femmesh, fem_object, group_data_type):
    # get ids from femmesh groupdata for reference shapes of each obj.References
    # we assume the mesh group data fits with the reference shapes
    # no check is done in this regard !!!
    # we just check for the group name and the group data type
    # what happens if a reference shape was changed
    # but the mesh and the mesh groups were not created new !?!
    obj = fem_object["Object"]
    exact = []
    legacy = []
    for group in femmesh.Groups:
        name = femmesh.getGroupName(group)
        kind = femmesh.getGroupElementType(group)
        if name == obj.Name and (
            kind == group_data_type or (kind == "All" and group_data_type != "Node")
        ):
            exact.append(group)
        elif name.startswith(obj.Name + "_") and kind == group_data_type:
            legacy.append(group)
    groups = exact or legacy
    if not groups:
        return ()
    allowed = (
        None if group_data_type == "Node" else set(femmesh.getIdByElementType(group_data_type))
    )
    elements = set()
    for group in groups:
        members = femmesh.getGroupElements(group)
        elements.update(members if allowed is None else allowed.intersection(members))
    return tuple(sorted(elements))


# ************************************************************************************************
def _get_solid_reference_group_sets(mesh_object, fem_objects, volumes):
    """Resolve current selections through persistent CAD entity groups.

    Analysis-object groups are snapshots of old selections. The entity groups,
    bound to the meshed geometry, also support legitimate material reassignment
    without trusting those snapshots or classifying every mesh node in CAD.
    None means a legacy mesh without this provenance, not invalid provenance.
    """
    if mesh_object is None:
        return None
    names = list(getattr(mesh_object, "ElementGroupNames", []))
    references = [
        (owner, name)
        for owner, items in getattr(mesh_object, "ElementGroupReferences", [])
        for name in items
    ]
    signature = getattr(mesh_object, "ElementGroupGeometry", "")
    if not (names or references or signature):
        return None
    part = getattr(mesh_object, "Shape", None)
    if not part or not signature or signature != get_mesh_geometry_signature(part):
        raise ValueError("Material mesh geometry changed; regenerate the mesh.")
    if len(names) != len(references) or len(names) != len(set(names)):
        raise ValueError("Invalid material mesh group provenance; regenerate the mesh.")
    current = {}
    for old, (owner, name) in zip(names, references):
        if owner != part:
            raise ValueError("Material mesh geometry owner changed; regenerate the mesh.")
        current.setdefault(name, []).append(old)
    mesh = mesh_object.FemMesh
    groups = {}
    for group in mesh.Groups:
        groups.setdefault(mesh.getGroupName(group), []).append(group)
    result = []
    for fem_object in fem_objects:
        obj = fem_object["Object"]
        selected = []
        for owner, subnames in obj.References:
            if owner is None or not subnames:
                raise ValueError(f"{obj.Name}: unresolved material references.")
            for subname in subnames:
                shape = owner.getSubObject(subname)
                if shape is None or shape.isNull():
                    raise ValueError(f"{obj.Name}: unresolved material reference {subname}.")
                if shape.ShapeType not in ("Solid", "Compound", "CompSolid"):
                    return None  # Preserve non-solid legacy selection behavior.
                proxy = SimpleNamespace(Name=obj.Name, References=[(owner, [subname])])
                wanted = get_reference_group_elements(proxy, part)[1]
                expected = 1 if shape.ShapeType == "Solid" else len(shape.Solids)
                if (
                    not wanted
                    or len(wanted) != expected
                    or any(not re.fullmatch(r"Solid[1-9][0-9]*", name) for name in wanted)
                ):
                    raise ValueError(
                        f"{obj.Name}: material reference is absent from mesh geometry."
                    )
                elements = set()
                for name in wanted:
                    originals = current.get(name, [])
                    if len(originals) != 1 or len(groups.get(originals[0], [])) != 1:
                        raise ValueError(f"{obj.Name}: missing or ambiguous mesh group for {name}.")
                    group = groups[originals[0]][0]
                    members = set(mesh.getGroupElements(group))
                    if (
                        mesh.getGroupElementType(group) not in ("All", "Volume")
                        or not members
                        or not members.issubset(volumes)
                    ):
                        raise ValueError(f"{obj.Name}: invalid volume group for {name}.")
                    elements.update(members)
                selected.append(((owner, (subname,)), tuple(sorted(elements)), False))
        result.append(selected)
    return result


def get_femelement_sets_from_group_data(femmesh, fem_objects, mesh_object=None):
    """Commit group-derived sets only after validating a complete volume partition."""
    volumes = set(femmesh.Volumes)
    reference_sets = _get_solid_reference_group_sets(mesh_object, fem_objects, volumes)
    assigned = set()
    pending = []
    default = None
    for index, fem_object in enumerate(fem_objects):
        obj = fem_object["Object"]
        if not obj.References:
            if default is not None:
                raise ValueError("Multiple default materials cannot partition mesh volumes.")
            default = fem_object
            continue
        if reference_sets is not None:
            elements = {element for _, members, _ in reference_sets[index] for element in members}
        else:
            # New All aggregates have no current-reference binding on old meshes.
            # Keep their supported geometric fallback, rather than trust a stale
            # material snapshot. Legacy typed groups retain their old contract.
            if mesh_object is not None and any(
                femmesh.getGroupName(group) == obj.Name
                and femmesh.getGroupElementType(group) == "All"
                for group in femmesh.Groups
            ):
                return False
            elements = set(get_femmesh_groupdata_sets_by_name(femmesh, fem_object, "Volume"))
        if not elements:
            return False  # An ungrouped legacy input still needs geometric selection.
        if elements - volumes:
            raise ValueError(f"{obj.Name}: material group contains non-volume elements.")
        if assigned.intersection(elements):
            raise ValueError(f"{obj.Name}: material groups overlap.")
        assigned.update(elements)
        pending.append((fem_object, elements))
    if default is not None:
        pending.append((default, volumes - assigned))
        assigned = volumes
    if assigned != volumes:
        raise ValueError("Material groups do not cover every mesh volume.")
    for i, fem_object in enumerate(fem_objects):
        fem_object["ShortName"] = get_elset_short_name(fem_object["Object"], i)
    for fem_object, elements in pending:
        fem_object["FEMElements"] = tuple(sorted(elements))
    if reference_sets is not None:
        for fem_object, selected in zip(fem_objects, reference_sets):
            fem_object["MaterialElements"] = selected
    else:
        for fem_object in fem_objects:
            fem_object.pop("MaterialElements", None)
    return True


# ************************************************************************************************
def get_elset_short_name(obj, i):
    # ATM for CalculiX needed for all objects which will write element sets into solver input file
    from femtools.femutils import is_of_type

    if is_of_type(obj, "Fem::MaterialCommon"):
        return "M" + str(i)
    elif is_of_type(obj, "Fem::ElementGeometry1D"):
        return "B" + str(i)
    elif is_of_type(obj, "Fem::ElementRotation1D"):
        return "R" + str(i)
    elif is_of_type(obj, "Fem::ElementFluid1D"):
        return "F" + str(i)
    elif is_of_type(obj, "Fem::ElementGeometry2D"):
        return "S" + str(i)
    elif is_of_type(obj, "Fem::ConstraintCentrif"):
        return "C" + str(i)
    elif is_of_type(obj, "Fem::ConstraintBodyHeatSource"):
        return "H" + str(i)
    else:
        FreeCAD.Console.PrintError(
            "Error in creating short elset name "
            "for obj: {} --> Proxy.Type: {}\n".format(obj.Name, obj.Proxy.Type)
        )


# ************************************************************************************************
# ***** methods for retrieving nodes and node load values for constraint force *******************
# ***** Vertex loads *****************************************************************************
def get_force_obj_vertex_nodeload_table(femmesh, frc_obj):
    # force_obj_node_load_table:
    #     [
    #         ("refshape_name.elemname", node_load_table),
    #         ...,
    #         ("refshape_name.elemname", node_load_table)
    #     ]
    force_obj_node_load_table = []
    force_quantity = FreeCAD.Units.Quantity(frc_obj.Force.getValueAs("N"))
    node_load = force_quantity / len(frc_obj.References)
    for o, elem_tup in frc_obj.References:
        node_count = len(elem_tup)
        for elem in elem_tup:
            ref_node = o.Shape.getElement(elem)
            FreeCAD.Console.PrintMessage(
                "    "
                "ReferenceShape ... Type: {}, "
                "Object name: {}, "
                "Object label: {}, "
                "Element name: {}\n".format(ref_node.ShapeType, o.Name, o.Label, elem)
            )
            node = femmesh.getNodesByVertex(ref_node)
            elem_info_string = "node load on shape: " + o.Name + ":" + elem
            if len(node) == 1:
                force_obj_node_load_table.append(
                    (elem_info_string, {node[0]: node_load / node_count})
                )
            else:
                FreeCAD.Console.PrintError(
                    f"    Problem on retrieving mesh node for: {elem_info_string}\n"
                )
    return force_obj_node_load_table


# ***** Edge loads *******************************************************************************
# get_force_obj_edge_nodeload_table
# get_ref_edgenodes_table
# get_ref_edgenodes_lengths
def get_force_obj_edge_nodeload_table(femmesh, femelement_table, femnodes_mesh, frc_obj):
    # force_obj_node_load_table:
    #     [
    #         ("refshape_name.elemname", node_load_table),
    #         ...,
    #         ("refshape_name.elemname", node_load_table)
    #     ]
    force_obj_node_load_table = []
    sum_ref_edge_length = 0
    sum_ref_edge_node_length = 0  # for debugging
    sum_node_load = 0  # for debugging
    for o, elem_tup in frc_obj.References:
        for elem in elem_tup:
            ref_edge = o.Shape.getElement(elem)
            FreeCAD.Console.PrintMessage(
                "    "
                "ReferenceShape ... Type: {}, "
                "Object name: {}, "
                "Object label: {}, "
                "Element name: {}\n".format(ref_edge.ShapeType, o.Name, o.Label, elem)
            )
            sum_ref_edge_length += ref_edge.Length
    if sum_ref_edge_length != 0:
        force_quantity = FreeCAD.Units.Quantity(frc_obj.Force.getValueAs("N"))
        force_per_sum_ref_edge_length = force_quantity / sum_ref_edge_length
    for o, elem_tup in frc_obj.References:
        for elem in elem_tup:
            ref_edge = o.Shape.getElement(elem)

            # edge_table:
            #     { meshedgeID : ( nodeID, ... , nodeID ) }
            edge_table = get_ref_edgenodes_table(femmesh, femelement_table, ref_edge)

            # node_length_table:
            #     [ (nodeID, length), ... , (nodeID, length) ]
            # some nodes will have more than one entry
            node_length_table = get_ref_edgenodes_lengths(femnodes_mesh, edge_table)

            # node_sum_length_table:
            #     { nodeID : Length, ... , nodeID : Length }
            # LengthSum for each node, one entry for each node
            node_sum_length_table = get_ref_shape_node_sum_geom_table(node_length_table)

            # node_load_table:
            #     { nodeID : NodeLoad, ... , nodeID : NodeLoad }
            # NodeLoad for each node, one entry for each node
            node_load_table = {}
            sum_node_lengths = 0  # for debugging
            for node in node_sum_length_table:
                sum_node_lengths += node_sum_length_table[node]  # for debugging
                node_load_table[node] = node_sum_length_table[node] * force_per_sum_ref_edge_length
            ratio_refedge_lengths = sum_node_lengths / ref_edge.Length
            if ratio_refedge_lengths < 0.99 or ratio_refedge_lengths > 1.01:
                FreeCAD.Console.PrintError(
                    "Error on: " + frc_obj.Name + " --> " + o.Name + "." + elem + "\n"
                )
                FreeCAD.Console.PrintMessage(f"  sum_node_lengths: {sum_node_lengths}\n")
                FreeCAD.Console.PrintMessage(f"  refedge_length: {ref_edge.Length}\n")
                bad_refedge = ref_edge
            sum_ref_edge_node_length += sum_node_lengths

            elem_info_string = "node loads on shape: " + o.Name + ":" + elem
            force_obj_node_load_table.append((elem_info_string, node_load_table))

    for ref_shape in force_obj_node_load_table:
        for node in ref_shape[1]:
            sum_node_load += ref_shape[1][node]  # for debugging

    force_quantity = FreeCAD.Units.Quantity(frc_obj.Force.getValueAs("N"))
    ratio = sum_node_load / force_quantity
    if ratio < 0.99 or ratio > 1.01:
        FreeCAD.Console.PrintMessage(
            f"Deviation  sum_node_load to frc_obj.Force is more than 1% : {ratio}\n"
        )
        FreeCAD.Console.PrintMessage(f"  sum_ref_edge_node_length: {sum_ref_edge_node_length}\n")
        FreeCAD.Console.PrintMessage(f"  sum_ref_edge_length:      {sum_ref_edge_length}\n")
        FreeCAD.Console.PrintMessage(f"  sum_node_load:            {sum_node_load}\n")
        FreeCAD.Console.PrintMessage(f"  frc_obj.Force:            {force_quantity}\n")
        FreeCAD.Console.PrintMessage(
            "  the reason could be simply a circle length --> "
            "see method get_ref_edge_node_lengths\n"
        )
        FreeCAD.Console.PrintMessage(
            "  the reason could also be a problem in retrieving the ref_edge_node_length\n"
        )

        # try debugging of the last bad refedge
        FreeCAD.Console.PrintMessage("DEBUGGING\n")
        FreeCAD.Console.PrintMessage(f"{bad_refedge}\n")

        FreeCAD.Console.PrintMessage("bad_refedge_nodes\n")
        bad_refedge_nodes = femmesh.getNodesByEdge(bad_refedge)
        FreeCAD.Console.PrintMessage(f"{len(bad_refedge_nodes)}\n")
        FreeCAD.Console.PrintMessage(f"{bad_refedge_nodes}\n")
        # import FreeCADGui
        # frc_obj.Document.Compound_Mesh.HighlightedNodes = bad_refedge_nodes

        FreeCAD.Console.PrintMessage("bad_edge_table\n")
        # bad_edge_table:
        #     { meshedgeID : ( nodeID, ... , nodeID ) }
        bad_edge_table = get_ref_edgenodes_table(femmesh, femelement_table, bad_refedge)
        FreeCAD.Console.PrintMessage(f"{len(bad_edge_table)}\n")
        bad_edge_table_nodes = []
        for elem in bad_edge_table:
            FreeCAD.Console.PrintMessage(elem, f" --> {bad_edge_table[elem]}\n")
            for node in bad_edge_table[elem]:
                if node not in bad_edge_table_nodes:
                    bad_edge_table_nodes.append(node)
        FreeCAD.Console.PrintMessage("sorted(bad_edge_table_nodes)\n")
        # should be == bad_refedge_nodes
        FreeCAD.Console.PrintMessage(f"{sorted(bad_edge_table_nodes)}\n")
        # import FreeCADGui
        # frc_obj.Document.Compound_Mesh.HighlightedNodes = bad_edge_table_nodes
        # bad_node_length_table:
        #     [ (nodeID, length), ... , (nodeID, length) ]
        # some nodes will have more than one entry

        FreeCAD.Console.PrintMessage("good_edge_table\n")
        good_edge_table = delete_duplicate_mesh_elements(bad_edge_table)
        for elem in good_edge_table:
            FreeCAD.Console.PrintMessage(f"{elem} --> {bad_edge_table[elem]}\n")

        FreeCAD.Console.PrintMessage("bad_node_length_table\n")
        bad_node_length_table = get_ref_edgenodes_lengths(femnodes_mesh, bad_edge_table)
        for n, l in bad_node_length_table:
            FreeCAD.Console.PrintMessage(f"{n} --> {l}\n")

    return force_obj_node_load_table


# ************************************************************************************************
def get_ref_edgenodes_table(femmesh, femelement_table, refedge):
    edge_table = {}  # { meshedgeID : ( nodeID, ... , nodeID ) }
    refedge_nodes = femmesh.getNodesByEdge(refedge)
    if is_solid_femmesh(femmesh):
        refedge_fem_volumeelements = []
        # if at least two nodes of a femvolumeelement are in
        # refedge_nodes the volume is added to refedge_fem_volumeelements
        for elem in femelement_table:
            nodecount = 0
            for node in femelement_table[elem]:
                if node in refedge_nodes:
                    nodecount += 1
            if nodecount > 1:
                refedge_fem_volumeelements.append(elem)
        # for every refedge_fem_volumeelement look which of its nodes
        # is in refedge_nodes --> add all these nodes to edge_table
        for elem in refedge_fem_volumeelements:
            fe_refedge_nodes = []
            for node in femelement_table[elem]:
                if node in refedge_nodes:
                    fe_refedge_nodes.append(node)
                # { volumeID : ( edgenodeID, ... , edgenodeID  )} # only the refedge nodes
                edge_table[elem] = fe_refedge_nodes
        # FIXME: duplicate_mesh_elements: as soon as contact and springs are supported
        # the user should decide on which edge the load is applied
        edge_table = delete_duplicate_mesh_elements(edge_table)
    elif is_face_femmesh(femmesh):
        refedge_fem_faceelements = []
        # if at least two nodes of a femfaceelement are in
        # refedge_nodes the volume is added to refedge_fem_volumeelements
        for elem in femelement_table:
            nodecount = 0
            for node in femelement_table[elem]:
                if node in refedge_nodes:
                    nodecount += 1
            if nodecount > 1:
                refedge_fem_faceelements.append(elem)
        # for every refedge_fem_faceelement look which of its nodes is in
        # refedge_nodes --> add all these nodes to edge_table
        for elem in refedge_fem_faceelements:
            fe_refedge_nodes = []
            for node in femelement_table[elem]:
                if node in refedge_nodes:
                    fe_refedge_nodes.append(node)
                # { faceID : ( edgenodeID, ... , edgenodeID  )} # only the refedge nodes
                edge_table[elem] = fe_refedge_nodes
        # FIXME: duplicate_mesh_elements: as soon as contact and springs are supported
        # the user should decide on which edge the load is applied
        edge_table = delete_duplicate_mesh_elements(edge_table)
    elif is_edge_femmesh(femmesh):
        refedge_fem_edgeelements = get_femelements_by_femnodes_std(femelement_table, refedge_nodes)
        for elem in refedge_fem_edgeelements:
            # { edgeID : ( nodeID, ... , nodeID  )} # all nodes off this femedgeelement
            edge_table[elem] = femelement_table[elem]
    return edge_table


# ************************************************************************************************
def get_ref_edgenodes_lengths(femnodes_mesh, edge_table):
    # calculate the appropriate node_length for every node of every mesh edge (me)
    # G. Lakshmi Narasaiah, Finite Element Analysis, p206ff

    #  [ (nodeID, length), ... , (nodeID, length) ]
    # some nodes will have more than one entry
    if (not femnodes_mesh) or (not edge_table):
        FreeCAD.Console.PrintError(
            "Error in get_ref_edgenodes_lengths(): Empty femnodes_mesh or edge_table!\n"
        )
        return []
    node_length_table = []
    mesh_edge_length = 0
    # FreeCAD.Console.PrintMessage("{}\n".format(len(edge_table)))
    for me in edge_table:
        femmesh_edgetype = len(edge_table[me])
        if femmesh_edgetype == 2:  # 2 node femmesh edge
            # end_node_length = mesh_edge_length / 2
            #    ______
            #  P1      P2
            P1 = femnodes_mesh[edge_table[me][0]]
            P2 = femnodes_mesh[edge_table[me][1]]
            edge_vec = P2 - P1
            mesh_edge_length = edge_vec.Length
            # FreeCAD.Console.PrintMessage("{}\n".format(mesh_edge_length))
            end_node_length = mesh_edge_length / 2.0
            node_length_table.append((edge_table[me][0], end_node_length))
            node_length_table.append((edge_table[me][1], end_node_length))

        elif femmesh_edgetype == 3:  # 3 node femmesh edge
            # end_node_length = mesh_edge_length / 6
            # middle_node_length = mesh_edge_length * 2 / 3
            #   _______ _______
            # P1       P3      P2
            P1 = femnodes_mesh[edge_table[me][0]]
            P2 = femnodes_mesh[edge_table[me][1]]
            P3 = femnodes_mesh[edge_table[me][2]]
            edge_vec1 = P3 - P1
            edge_vec2 = P2 - P3
            mesh_edge_length = edge_vec1.Length + edge_vec2.Length
            # FreeCAD.Console.PrintMessage("{} --> {}\n".format(me, mesh_edge_length))
            end_node_length = mesh_edge_length / 6.0
            middle_node_length = mesh_edge_length * 2.0 / 3.0
            node_length_table.append((edge_table[me][0], end_node_length))
            node_length_table.append((edge_table[me][1], end_node_length))
            node_length_table.append((edge_table[me][2], middle_node_length))
    return node_length_table


# ***** Face loads *******************************************************************************
# get_force_obj_face_nodeload_table
# get_ref_facenodes_table
# get_ref_facenodes_areas
# build_mesh_faces_of_volume_elements
def get_force_obj_face_nodeload_table(femmesh, femelement_table, femnodes_mesh, frc_obj):
    # force_obj_node_load_table:
    #     [
    #         ("refshape_name.elemname",node_load_table),
    #         ...,
    #         ("refshape_name.elemname",node_load_table)
    #     ]
    force_obj_node_load_table = []
    sum_ref_face_area = 0
    sum_ref_face_node_area = 0  # for debugging
    sum_node_load = 0  # for debugging
    for o, elem_tup in frc_obj.References:
        for elem in elem_tup:
            ref_face = sub_shape_at_global_placement(o, elem)
            FreeCAD.Console.PrintMessage(
                "    "
                "ReferenceShape ... Type: {}, "
                "Object name: {}, "
                "Object label: {}, "
                "Element name: {}\n".format(ref_face.ShapeType, o.Name, o.Label, elem)
            )
            sum_ref_face_area += ref_face.Area
    if sum_ref_face_area != 0:
        force_quantity = FreeCAD.Units.Quantity(frc_obj.Force.getValueAs("N"))
        force_per_sum_ref_face_area = force_quantity / sum_ref_face_area
    for o, elem_tup in frc_obj.References:
        for elem in elem_tup:
            ref_face = sub_shape_at_global_placement(o, elem)

            # face_table:
            #    { meshfaceID : ( nodeID, ... , nodeID ) }
            face_table = get_ref_facenodes_table(femmesh, femelement_table, ref_face)

            # node_area_table:
            #    [ (nodeID, Area), ... , (nodeID, Area) ]
            # some nodes will have more than one entry
            node_area_table = get_ref_facenodes_areas(femnodes_mesh, face_table)

            # node_sum_area_table:
            #    { nodeID : Area, ... , nodeID : Area }
            # AreaSum for each node, one entry for each node
            node_sum_area_table = get_ref_shape_node_sum_geom_table(node_area_table)

            # node_load_table:
            #    { nodeID : NodeLoad, ... , nodeID : NodeLoad }
            # NodeLoad for each node, one entry for each node
            node_load_table = {}
            sum_node_areas = 0  # for debugging
            for node in node_sum_area_table:
                sum_node_areas += node_sum_area_table[node]  # for debugging
                node_load_table[node] = node_sum_area_table[node] * force_per_sum_ref_face_area
            ratio_refface_areas = sum_node_areas / ref_face.Area
            if ratio_refface_areas < 0.99 or ratio_refface_areas > 1.01:
                FreeCAD.Console.PrintError(
                    "Error on: " + frc_obj.Name + " --> " + o.Name + "." + elem + "\n"
                )
                FreeCAD.Console.PrintMessage(f"  sum_node_areas: {sum_node_areas}\n")
                FreeCAD.Console.PrintMessage(f"  ref_face_area:  {ref_face.Area}\n")
            sum_ref_face_node_area += sum_node_areas

            elem_info_string = "node loads on shape: " + o.Name + ":" + elem
            force_obj_node_load_table.append((elem_info_string, node_load_table))

    for ref_shape in force_obj_node_load_table:
        for node in ref_shape[1]:
            sum_node_load += ref_shape[1][node]  # for debugging

    force_quantity = FreeCAD.Units.Quantity(frc_obj.Force.getValueAs("N"))
    ratio = sum_node_load / force_quantity
    if ratio < 0.99 or ratio > 1.01:
        FreeCAD.Console.PrintMessage(
            f"Deviation sum_node_load to frc_obj.Force is more than 1% :  {ratio}\n"
        )
        FreeCAD.Console.PrintMessage(f"  sum_ref_face_node_area: {sum_ref_face_node_area}\n")
        FreeCAD.Console.PrintMessage(f"  sum_ref_face_area:      {sum_ref_face_area}\n")
        FreeCAD.Console.PrintMessage(f"  sum_node_load:          {sum_node_load}\n")
        FreeCAD.Console.PrintMessage(f"  frc_obj.Force:          {force_quantity}\n")
        FreeCAD.Console.PrintMessage(
            "  the reason could be simply a circle area --> see method get_ref_face_node_areas\n"
        )
        FreeCAD.Console.PrintMessage(
            "  the reason could also be a problem in retrieving the ref_face_node_area\n"
        )

    return force_obj_node_load_table


# ************************************************************************************************
def get_ref_facenodes_table(femmesh, femelement_table, ref_face):
    face_table = {}  # { meshfaceID : ( nodeID, ... , nodeID ) }
    if is_solid_femmesh(femmesh):
        if has_no_face_data(femmesh):
            FreeCAD.Console.PrintMessage(
                "  No face data in finite volume element mesh. "
                "FreeCAD uses getccxVolumesByFace() "
                "to retrieve the volume elements of the ref_face.\n"
            )
            # there is no face data
            # if we retrieve the nodes ourself we will have a problem:
            # they are not sorted, we just have the nodes.
            # We need to sort them according to the
            # shell mesh notation of tria3, tria6, quad4, quad8
            ref_face_nodes = femmesh.getNodesByFace(ref_face)
            # try to use getccxVolumesByFace() to get the volume ids
            # of element with elementfaces on the ref_face
            # --> should work for tetra4 and tetra10
            # list of tuples (mv, ccx_face_nr)
            ref_face_volume_elements = femmesh.getccxVolumesByFace(ref_face)
            if ref_face_volume_elements:  # mesh with tetras
                FreeCAD.Console.PrintLog(
                    "  Use of getccxVolumesByFace() has "
                    "returned volume elements of the ref_face.\n"
                )
                for ve in ref_face_volume_elements:
                    veID = ve[0]
                    ve_ref_face_nodes = []
                    for nodeID in femelement_table[veID]:
                        if nodeID in ref_face_nodes:
                            ve_ref_face_nodes.append(nodeID)
                    # { volumeID : ( facenodeID, ... , facenodeID ) } only the ref_face nodes
                    face_table[veID] = ve_ref_face_nodes
            else:  # mesh with hexa or penta
                FreeCAD.Console.PrintLog(
                    "  The use of getccxVolumesByFace() has NOT returned "
                    "volume elements of the ref_face. "
                    "FreeCAD tries to use get_femvolumeelements_by_femfacenodes().\n"
                )
                # list of integer [mv]
                ref_face_volume_elements = get_femvolumeelements_by_femfacenodes(
                    femelement_table, ref_face_nodes
                )
                for veID in ref_face_volume_elements:
                    ve_ref_face_nodes = []
                    for nodeID in femelement_table[veID]:
                        if nodeID in ref_face_nodes:
                            ve_ref_face_nodes.append(nodeID)
                    # { volumeID : ( facenodeID, ... , facenodeID ) } only the ref_face nodes
                    face_table[veID] = ve_ref_face_nodes
                # we need to resort the nodes to make them build an element face
                face_table = build_mesh_faces_of_volume_elements(face_table, femelement_table)
        else:  # the femmesh has face_data
            faces = femmesh.getFacesByFace(ref_face)  # (mv, mf)
            for mf in faces:
                face_table[mf] = femmesh.getElementNodes(mf)
    elif is_face_femmesh(femmesh):
        ref_face_nodes = femmesh.getNodesByFace(ref_face)
        ref_face_elements = get_femelements_by_femnodes_std(femelement_table, ref_face_nodes)
        for mf in ref_face_elements:
            face_table[mf] = femelement_table[mf]
    # FreeCAD.Console.PrintMessage("{}\n".format(face_table))
    return face_table


# ************************************************************************************************
def get_ref_facenodes_areas(femnodes_mesh, face_table):
    # calculate the appropriate node_areas for every node of every mesh face (mf)
    # G. Lakshmi Narasaiah, Finite Element Analysis, p206ff
    # FIXME: only gives exact results in case of a real triangle. If for S6 or C3D10 elements
    # the midnodes are not on the line between the end nodes the area will not be a triangle
    # see https://forum.freecad.org/viewtopic.php?f=18&t=10939&start=40#p91355  and ff
    # same applies for the quads
    # results are exact only if mid nodes are on the line between corner nodes

    #  [ (nodeID,Area), ... , (nodeID,Area) ]  some nodes will have more than one entry
    if (not femnodes_mesh) or (not face_table):
        FreeCAD.Console.PrintError("Error: Empty femnodes_mesh or face_table!\n")
        return []
    node_area_table = []
    mesh_face_area = 0
    for mf in face_table:
        femmesh_facetype = len(face_table[mf])
        # nodes in face_table need to be in the right node order for the following calculations
        if femmesh_facetype == 3:  # 3 node femmesh face triangle
            # corner_node_area = mesh_face_area / 3.0
            #      P3
            #      /\
            #     /  \
            #    /____\
            #  P1      P2
            P1 = femnodes_mesh[face_table[mf][0]]
            P2 = femnodes_mesh[face_table[mf][1]]
            P3 = femnodes_mesh[face_table[mf][2]]

            mesh_face_area = get_triangle_area(P1, P2, P3)
            corner_node_area = mesh_face_area / 3.0

            node_area_table.append((face_table[mf][0], corner_node_area))
            node_area_table.append((face_table[mf][1], corner_node_area))
            node_area_table.append((face_table[mf][2], corner_node_area))

        elif femmesh_facetype == 4:  # 4 node femmesh face quad
            # corner_node_area = mesh_face_area / 4.0
            #  P4_______P3
            #    |     /|
            #    | t2 / |
            #    |   /  |
            #    |  /   |
            #    | / t1 |
            #    |/_____|
            #  P1       P2
            P1 = femnodes_mesh[face_table[mf][0]]
            P2 = femnodes_mesh[face_table[mf][1]]
            P3 = femnodes_mesh[face_table[mf][2]]
            P4 = femnodes_mesh[face_table[mf][3]]

            mesh_face_t1_area = get_triangle_area(P1, P2, P3)
            mesh_face_t2_area = get_triangle_area(P1, P3, P4)
            mesh_face_area = mesh_face_t1_area + mesh_face_t2_area
            corner_node_area = mesh_face_area / 4.0

            node_area_table.append((face_table[mf][0], corner_node_area))
            node_area_table.append((face_table[mf][1], corner_node_area))
            node_area_table.append((face_table[mf][2], corner_node_area))
            node_area_table.append((face_table[mf][3], corner_node_area))

        elif femmesh_facetype == 6:  # 6 node femmesh face triangle
            # corner_node_area = 0
            # middle_node_area = mesh_face_area / 3.0
            #         P3
            #         /\
            #        /t3\
            #       /    \
            #     P6------P5
            #     / \ t4 / \
            #    /t1 \  /t2 \
            #   /_____\/_____\
            # P1      P4      P2
            P1 = femnodes_mesh[face_table[mf][0]]
            P2 = femnodes_mesh[face_table[mf][1]]
            P3 = femnodes_mesh[face_table[mf][2]]
            P4 = femnodes_mesh[face_table[mf][3]]
            P5 = femnodes_mesh[face_table[mf][4]]
            P6 = femnodes_mesh[face_table[mf][5]]

            mesh_face_t1_area = get_triangle_area(P1, P4, P6)
            mesh_face_t2_area = get_triangle_area(P2, P5, P4)
            mesh_face_t3_area = get_triangle_area(P3, P6, P5)
            mesh_face_t4_area = get_triangle_area(P4, P5, P6)
            mesh_face_area = (
                mesh_face_t1_area + mesh_face_t2_area + mesh_face_t3_area + mesh_face_t4_area
            )
            middle_node_area = mesh_face_area / 3.0

            node_area_table.append((face_table[mf][0], 0))
            node_area_table.append((face_table[mf][1], 0))
            node_area_table.append((face_table[mf][2], 0))
            node_area_table.append((face_table[mf][3], middle_node_area))
            node_area_table.append((face_table[mf][4], middle_node_area))
            node_area_table.append((face_table[mf][5], middle_node_area))

        elif femmesh_facetype == 8:  # 8 node femmesh face quad
            # corner_node_area = -mesh_face_area / 12.0  (negative!)
            # mid-side nodes = mesh_face_area / 3.0
            #  P4_________P7________P3
            #    |      / |  \      |
            #    | t4 /   |    \ t3 |
            #    |  /     |      \  |
            #    |/       |        \|
            #  P8|    t5  |   t6    |P6
            #    |\       |       / |
            #    |  \     |     /   |
            #    | t1 \   |   /  t2 |
            #    |______\_|_/_______|
            #  P1         P5        P2
            P1 = femnodes_mesh[face_table[mf][0]]
            P2 = femnodes_mesh[face_table[mf][1]]
            P3 = femnodes_mesh[face_table[mf][2]]
            P4 = femnodes_mesh[face_table[mf][3]]
            P5 = femnodes_mesh[face_table[mf][4]]
            P6 = femnodes_mesh[face_table[mf][5]]
            P7 = femnodes_mesh[face_table[mf][6]]
            P8 = femnodes_mesh[face_table[mf][7]]

            mesh_face_t1_area = get_triangle_area(P1, P5, P8)
            mesh_face_t2_area = get_triangle_area(P5, P2, P6)
            mesh_face_t3_area = get_triangle_area(P6, P3, P7)
            mesh_face_t4_area = get_triangle_area(P7, P4, P8)
            mesh_face_t5_area = get_triangle_area(P5, P7, P8)
            mesh_face_t6_area = get_triangle_area(P5, P6, P7)
            mesh_face_area = (
                mesh_face_t1_area
                + mesh_face_t2_area
                + mesh_face_t3_area
                + mesh_face_t4_area
                + mesh_face_t5_area
                + mesh_face_t6_area
            )
            corner_node_area = -mesh_face_area / 12.0
            middle_node_area = mesh_face_area / 3.0

            node_area_table.append((face_table[mf][0], corner_node_area))
            node_area_table.append((face_table[mf][1], corner_node_area))
            node_area_table.append((face_table[mf][2], corner_node_area))
            node_area_table.append((face_table[mf][3], corner_node_area))
            node_area_table.append((face_table[mf][4], middle_node_area))
            node_area_table.append((face_table[mf][5], middle_node_area))
            node_area_table.append((face_table[mf][6], middle_node_area))
            node_area_table.append((face_table[mf][7], middle_node_area))
    return node_area_table


# ************************************************************************************************
def build_mesh_faces_of_volume_elements(face_table, femelement_table):
    # node index of facenodes in femelementtable volume element
    # if we know the position of the node
    # we can build the element face out of the unsorted face nodes
    face_nodenumber_table = {}  # { volumeID : ( index, ... , index ) }
    for veID in face_table:
        face_nodenumber_table[veID] = []
        for n in face_table[veID]:
            index = femelement_table[veID].index(n)
            # FreeCAD.Console.PrintMessage("{}\n".format(index))
            # local node number = index + 1
            face_nodenumber_table[veID].append(index + 1)
        FreeCAD.Console.PrintLog(f"VolElement: {veID}\n")
        FreeCAD.Console.PrintLog(f"  --> {femelement_table[veID]}\n")
        FreeCAD.Console.PrintLog(f"  --> {face_table[veID]}\n")
        FreeCAD.Console.PrintLog(f"  --> {face_nodenumber_table[veID]}\n")

    for veID in face_nodenumber_table:
        FreeCAD.Console.PrintLog(f"VolElement: {veID}\n")
        vol_node_ct = len(femelement_table[veID])
        face_node_indexs = sorted(face_nodenumber_table[veID])
        node_numbers = ()
        if vol_node_ct == 10:
            FreeCAD.Console.PrintLog("  --> tetra10 --> tria6 face\n")
            # node order of face in tetra10 volume element
            if face_node_indexs == [1, 2, 3, 5, 6, 7]:
                # node order of a tria6 face of tetra10
                node_numbers = (1, 2, 3, 5, 6, 7)
            elif face_node_indexs == [1, 2, 4, 5, 8, 9]:
                node_numbers = (1, 4, 2, 8, 9, 5)
            elif face_node_indexs == [1, 3, 4, 7, 8, 10]:
                node_numbers = (1, 3, 4, 7, 10, 8)
            elif face_node_indexs == [2, 3, 4, 6, 9, 10]:
                node_numbers = (2, 4, 3, 9, 10, 6)
            else:
                FreeCAD.Console.PrintError(
                    "Error in build_mesh_faces_of_volume_elements(): "
                    "tetra10: face not found! {}\n".format(face_node_indexs)
                )
        elif vol_node_ct == 4:
            FreeCAD.Console.PrintLog("  --> tetra4 --> tria3 face\n")
            # node order of face in tetra4 volume element
            if face_node_indexs == [1, 2, 3]:
                # node order of a tria3 face of tetra4
                node_numbers = (1, 2, 3)
            elif face_node_indexs == [1, 2, 4]:
                node_numbers = (1, 4, 2, 8)
            elif face_node_indexs == [1, 3, 4]:
                node_numbers = (1, 3, 4)
            elif face_node_indexs == [2, 3, 4]:
                node_numbers = (2, 4, 3)
            else:
                FreeCAD.Console.PrintError(
                    "Error in build_mesh_faces_of_volume_elements(): "
                    "tetra4: face not found! {}\n".format(face_node_indexs)
                )
        elif vol_node_ct == 20:
            FreeCAD.Console.PrintLog("  --> hexa20 --> quad8 face\n")
            # node order of face in hexa20 volume element
            if face_node_indexs == [1, 2, 3, 4, 9, 10, 11, 12]:
                # node order of a quad8 face of hexa20
                node_numbers = (1, 2, 3, 4, 9, 10, 11, 12)
            elif face_node_indexs == [5, 6, 7, 8, 13, 14, 15, 16]:
                node_numbers = (5, 8, 7, 6, 16, 15, 14, 13)
            elif face_node_indexs == [1, 2, 5, 6, 9, 13, 17, 18]:
                node_numbers = (1, 5, 6, 2, 17, 13, 18, 9)
            elif face_node_indexs == [3, 4, 7, 8, 11, 15, 19, 20]:
                node_numbers = (3, 7, 8, 4, 19, 15, 20, 11)
            elif face_node_indexs == [1, 4, 5, 8, 12, 16, 17, 20]:
                node_numbers = (1, 4, 8, 5, 12, 20, 16, 17)
            elif face_node_indexs == [2, 3, 6, 7, 10, 14, 18, 19]:
                node_numbers = (2, 6, 7, 3, 18, 14, 19, 10)
            else:
                FreeCAD.Console.PrintError(
                    "Error in build_mesh_faces_of_volume_elements(): "
                    "hexa20: face not found! {}\n".format(face_node_indexs)
                )
        elif vol_node_ct == 8:
            FreeCAD.Console.PrintLog("  --> hexa8 --> quad4 face\n")
            # node order of face in hexa8 volume element
            if face_node_indexs == [1, 2, 3, 4]:
                # node order of a quad8 face of hexa8
                node_numbers = (1, 2, 3, 4)
            elif face_node_indexs == [5, 6, 7, 8]:
                node_numbers = (5, 8, 7, 6)
            elif face_node_indexs == [1, 2, 5, 6]:
                node_numbers = (1, 5, 6, 2)
            elif face_node_indexs == [3, 4, 7, 8]:
                node_numbers = (3, 7, 8, 4)
            elif face_node_indexs == [1, 4, 5, 8]:
                node_numbers = (1, 4, 8, 5)
            elif face_node_indexs == [2, 3, 6, 7]:
                node_numbers = (2, 6, 7, 3)
            else:
                FreeCAD.Console.PrintError(
                    "Error in build_mesh_faces_of_volume_elements(): "
                    "hexa8: face not found! {}\n".format(face_node_indexs)
                )
        elif vol_node_ct == 15:
            FreeCAD.Console.PrintLog("  --> penta15 --> tria6 and quad8 faces\n")
            # node order of face in penta15 volume element
            if face_node_indexs == [1, 2, 3, 7, 8, 9]:
                # node order of a tria6 face of penta15
                node_numbers = (1, 2, 3, 7, 8, 9)
            elif face_node_indexs == [4, 5, 6, 10, 11, 12]:
                node_numbers = (4, 6, 5, 12, 11, 10)  # tria6
            elif face_node_indexs == [1, 2, 4, 5, 7, 10, 13, 14]:
                node_numbers = (1, 4, 5, 2, 13, 10, 14, 7)  # quad8
            elif face_node_indexs == [1, 3, 4, 6, 9, 12, 13, 15]:
                node_numbers = (1, 3, 6, 4, 9, 15, 12, 13)  # quad8
            elif face_node_indexs == [2, 3, 5, 6, 8, 11, 14, 15]:
                node_numbers = (2, 5, 6, 3, 14, 11, 15, 8)  # quad8
            else:
                FreeCAD.Console.PrintError(
                    "Error in build_mesh_faces_of_volume_elements(): "
                    "penta15: face not found! {}\n".format(face_node_indexs)
                )
        elif vol_node_ct == 6:
            FreeCAD.Console.PrintLog("  --> penta6 --> tria3 and quad4 faces\n")
            # node order of face in penta6 volume element
            if face_node_indexs == [1, 2, 3]:
                # node order of a tria3 face of penta6
                node_numbers = (1, 2, 3)
            elif face_node_indexs == [4, 5, 6]:
                node_numbers = (4, 6, 5)  # tria3
            elif face_node_indexs == [1, 2, 4, 5]:
                node_numbers = (1, 4, 5, 2)  # quad4
            elif face_node_indexs == [1, 3, 4, 6]:
                node_numbers = (1, 3, 6, 4)  # quad4
            elif face_node_indexs == [2, 3, 5, 6]:
                node_numbers = (2, 5, 6, 3)  # quad4
            else:
                FreeCAD.Console.PrintError(
                    "Error in build_mesh_faces_of_volume_elements(): "
                    "penta6: face not found! {}\n".format(face_node_indexs)
                )
        else:
            FreeCAD.Console.PrintError(
                "Error in build_mesh_faces_of_volume_elements(): "
                "Volume not implemented: volume node count {}\n".format(vol_node_ct)
            )
        face_nodes = []
        for i in node_numbers:
            # node_number starts with 1
            # index starts with 0 -->
            # index = node number - 1
            i -= 1
            face_nodes.append(femelement_table[veID][i])
        face_table[veID] = face_nodes  # reset the entry in face_table
        FreeCAD.Console.PrintLog(f"  --> {face_table[veID]}\n")
    return face_table


# ***** helper for Face and Edge loads ***********************************************************
def get_ref_shape_node_sum_geom_table(node_geom_table):
    # shape could be Edge or Face, geom could be length or area
    # sum of length or area for each node of the ref_shape
    node_sum_geom_table = {}
    for n, A in node_geom_table:
        # FreeCAD.Console.PrintMessage("{} --> {}\n".format(n, A))
        if n in node_sum_geom_table:
            node_sum_geom_table[n] = node_sum_geom_table[n] + A
        else:
            node_sum_geom_table[n] = A
    return node_sum_geom_table


# ************************************************************************************************
# ***** methods for retrieving element face sets *************************************************
# ***** charged faces ****************************************************************************
def pair_obj_reference(obj_ref):
    pairs = []
    for feat, ref in obj_ref:
        for sub_ref in ref:
            sub = (feat, sub_ref)
            pairs.append(sub)

    return pairs


def get_elements(sets_getter, ref_pair, face_masks, edge_masks):
    ref_obj, sub_ref = ref_pair
    geom_type = ref_obj.getSubObject(sub_ref).ShapeType
    elem = []
    is_sub_element = False
    model_dim = 0
    if is_solid_femmesh(sets_getter.femmesh):
        model_dim = 3
    elif is_face_femmesh(sets_getter.femmesh):
        model_dim = 2
    elif is_edge_femmesh(sets_getter.femmesh):
        model_dim = 1

    match model_dim:
        case 3:
            match geom_type:
                case "Solid":
                    elem = get_elements_by_references(sets_getter, ref_pair)
                    is_sub_element = False
                case "Face" | "Edge" | "Vertex":
                    elem = get_subelements_by_references(
                        sets_getter, ref_pair, face_masks, edge_masks
                    )
                    is_sub_element = True
        case 2:
            match geom_type:
                case "Face":
                    elem = get_elements_by_references(sets_getter, ref_pair)
                    is_sub_element = False
                case "Edge" | "Vertex":
                    elem = get_subelements_by_references(
                        sets_getter, ref_pair, face_masks, edge_masks
                    )
                    is_sub_element = True
        case 1:
            match geom_type:
                case "Edge":
                    is_sub_element = False
                    elem = get_elements_by_references(sets_getter, ref_pair)
                case "Vertex":
                    elem = get_subelements_by_references(
                        sets_getter, ref_pair, face_masks, edge_masks
                    )
                    is_sub_element = True
        case 0:
            match geom_type:
                case "Vertex":
                    elem = get_elements_by_references(sets_getter, ref_pair)
                    is_sub_element = False

    return (*elem, is_sub_element)


def get_contact_elements(sets_getter, contact, ref_pair, context=None):
    """Resolve Contact faces while retaining the existing public entry point."""
    return _get_owned_interface_elements(sets_getter, contact, ref_pair, context, "Contact")


def _get_owned_interface_elements(sets_getter, constraint, ref_pair, context, kind):
    """Resolve solid interface faces by complete, independently owned mesh patches.

    Retain the existing shell/non-face representation and solver face numbers.
    Native CAD face groups define the patches; coordinates never choose owners.
    """
    feature, name = ref_pair
    shape = feature.getSubObject(name) if feature is not None else None
    # A native null TopoShape raises when its ShapeType property is read.
    if (shape is None or not hasattr(shape, "isNull") or shape.isNull()
            or not hasattr(shape, "ShapeType")):
        raise ValueError(f"{constraint.Name}: unresolved {kind} region; select a current face.")
    if not is_solid_femmesh(sets_getter.femmesh) or shape.ShapeType != "Face":
        return get_elements(sets_getter, ref_pair, sets_getter.face_masks, sets_getter.edge_masks)

    _validate_interface_face_reference(constraint, feature, name, kind)
    reference = (feature, (name,))
    region = SimpleNamespace(Name=constraint.Name, References=[reference])
    nodes, entities = _get_mesh_region_by_owned_references(
        sets_getter.femmesh, region, sets_getter.mesh_object, context
    )
    if entities is None:
        _check_legacy_interface_ownership(sets_getter, constraint, ref_pair, kind)
        bits = get_bit_pattern_dict(
            sets_getter.femelement_table, sets_getter.femnodes_ele_table, nodes
        )
        return reference, get_element_faces_from_binary_search(bits, **sets_getter.face_masks), True

    mesh = sets_getter.femmesh
    face_ids = {element for members in entities.values() for element in members}
    patches = {
        frozenset(mesh.getElementNodes(element) if context is None else context.elements[element])
        for element in face_ids
    }
    faces = mesh.Faces if context is None else context.faces
    if not face_ids or not face_ids.issubset(faces) or len(patches) != len(face_ids):
        raise ValueError(f"{constraint.Name}: invalid owned {kind} face connectivity; remesh.")
    incident = {patch: [] for patch in patches}
    # Only inspect volumes incident to selected nodes, retaining sparse IDs.
    candidates = {
        element
        for node in nodes
        for element, _position in sets_getter.femnodes_ele_table.get(node, [])
    }
    mask_names = {4: "tetra4", 10: "tetra10", 8: "hexa8", 20: "hexa20", 6: "penta6", 15: "penta15"}
    for element in sorted(candidates):
        connectivity = sets_getter.femelement_table[element]
        volume_kind = mask_names.get(len(connectivity))
        masks = sets_getter.face_masks.get("mask_" + volume_kind, {}) if volume_kind else {}
        if not masks:
            raise ValueError(f"{constraint.Name}: unsupported {kind} volume face masks.")
        for mask, side in masks.items():
            patch = frozenset(
                node for index, node in enumerate(connectivity) if mask & (1 << index)
            )
            if patch in incident:
                incident[patch].append((element, side))
    facets = []
    for adjacent in incident.values():
        if not adjacent:
            raise ValueError(f"{constraint.Name}: owned {kind} face has no volume side; remesh.")
        if len(adjacent) != 1:
            raise ValueError(
                f"{constraint.Name}: ambiguous {kind} ownership: a face patch has multiple "
                f"volume sides; use independently meshed {kind} regions."
            )
        facets.append(adjacent[0])
    return reference, sorted(facets), True


def _validate_interface_face_reference(constraint, feature, name, kind):
    resolved, mapped, indexed = feature.resolveSubElement(name)
    if resolved is None or (not mapped and (
            ";" in name or re.fullmatch(r"Face[1-9][0-9]*", indexed) is None)):
        raise ValueError(f"{constraint.Name}: unresolved {kind} face reference; reselect the face.")
    return resolved, indexed


def _check_legacy_interface_ownership(sets_getter, constraint, ref_pair, kind):
    """A geometric fallback cannot distinguish overlapping independent owners."""
    part = getattr(sets_getter.mesh_object, "Shape", None)

    def canonical(pair):
        feature, name = pair
        resolved, indexed = _validate_interface_face_reference(constraint, feature, name, kind)
        # Resolving a link to an assembly can return its shared base feature.
        # Preserve the native occurrence chain while normalizing name aliases.
        links = tuple(item for item in feature.getSubObjectList(name)
                      if item.getLinkedObject() != item)
        if not links and part and part.isDerivedFrom("Part::Compound"):
            if resolved == part:
                return (), part, indexed
            entity = _get_compound_reference_element(part, resolved, indexed, "Face")
            if entity:
                return (), part, entity
        return links, resolved, indexed

    feature, name = ref_pair
    selected_key = canonical(ref_pair)
    selected = sub_shape_at_global_placement(feature, name)
    for other_feature, other_name in pair_obj_reference(constraint.References):
        if other_feature is None:
            raise ValueError(f"{constraint.Name}: unresolved {kind} region references.")
        other_shape = other_feature.getSubObject(other_name)
        if (other_shape is None or not hasattr(other_shape, "isNull") or other_shape.isNull()
                or not hasattr(other_shape, "ShapeType")):
            raise ValueError(f"{constraint.Name}: unresolved {kind} region references.")
        if other_shape.ShapeType != "Face":
            continue
        if canonical((other_feature, other_name)) == selected_key:
            continue  # The same region, including native reference aliases.
        other = sub_shape_at_global_placement(other_feature, other_name)
        scale = max(1., selected.BoundBox.DiagonalLength, other.BoundBox.DiagonalLength)
        if selected.common(other).Area > FreeCAD.Base.Precision.confusion() * scale:
            raise ValueError(
                f"{constraint.Name}: overlapping {kind} faces require owned mesh groups; remesh.")


def get_sectionprint_one_sided_faces(sets_getter, face_set):
    """Select one incident solid face per patch for signed section resultants.

    The generic node search deliberately returns both sides of internal faces
    (other constraints need them). Section Print instead needs the volume whose
    outward face normal follows the referenced CAD face normal. A boundary patch
    has only one incident volume and must be kept regardless of CAD orientation.
    Shell and non-face sets retain their existing writer representation.
    """
    refs, sides, is_sub_element = face_set
    if not is_sub_element or not is_solid_femmesh(sets_getter.femmesh):
        return face_set
    face = refs[0].getSubObject(refs[1][0])
    if face.ShapeType != "Face":
        return face_set

    mask_names = {4: "tetra4", 10: "tetra10", 8: "hexa8", 20: "hexa20",
                  6: "penta6", 15: "penta15"}
    patches = {}
    for element, side in sides:
        nodes = sets_getter.femelement_table[element]
        masks = sets_getter.face_masks["mask_" + mask_names[len(nodes)]]
        mask = next(mask for mask, number in masks.items() if number == side)
        # Include midside nodes: different quadratic patches must not be merged.
        patch = frozenset(node for index, node in enumerate(nodes) if mask & (1 << index))
        patches.setdefault(patch, []).append((element, side))

    def center(nodes):
        return sum((sets_getter.femnodes_mesh[node] for node in nodes), FreeCAD.Vector()) / len(nodes)

    keep = set()
    for nodes, incident in patches.items():
        if len(incident) == 1:
            keep.add(incident[0])
            continue
        if len(incident) != 2:
            raise ValueError("Section Print requires a manifold section: more than two incident volumes")
        point = center(nodes)
        normal = face.normalAt(*face.Surface.parameter(point))
        aligned = []
        for element, side in incident:
            outward = point - center(sets_getter.femelement_table[element])
            if normal.dot(outward) > 1e-10 * normal.Length * outward.Length:
                aligned.append((element, side))
        if len(aligned) != 1:
            raise ValueError("Section Print cannot determine a unique oriented incident volume")
        keep.add(aligned[0])

    return refs, [side for side in sides if tuple(side) in keep], is_sub_element


def get_elements_by_references(sets_getter, femobj_ref):
    node_set = []
    result = []
    # TODO get elements from mesh groups
    # if femmesh.GroupCount:
    #     node_set = get_femmesh_groupdata_sets_by_name(femmesh, femobj, "Node")
    #     # FreeCAD.Console.PrintMessage("node_set_group: {}\n".format(node_set))
    #     if node_set:
    #         FreeCAD.Console.PrintLog(
    #             "    Finite element mesh nodes where retrieved "
    #             "from existent finite element mesh group data.\n"
    #         )
    if not node_set:
        elem = []
        FreeCAD.Console.PrintLog(
            "    Finite element mesh nodes will be retrieved "
            "by searching the appropriate nodes in the finite element mesh.\n"
        )
        feat, sub_ref = femobj_ref
        sub = (feat, (sub_ref,))
        node_set = get_femnodes_by_references(sets_getter.femmesh, [sub])
        charged_volume_node_set = sorted(set(node_set))

        bit_pattern_dict = get_bit_pattern_dict(
            sets_getter.femelement_table, sets_getter.femnodes_ele_table, charged_volume_node_set
        )
        sh = feat.getSubObject(sub_ref)
        if sh.ShapeType == "Solid":
            elem = get_element_volumes_elements_from_binary_search(bit_pattern_dict)
        elif sh.ShapeType == "Face":
            elem = get_element_faces_elements_from_binary_search(bit_pattern_dict)
        elif sh.ShapeType == "Edge":
            elem = get_element_edges_elements_from_binary_search(bit_pattern_dict)

        result = (sub, elem)

    return result


def get_subelements_by_references(sets_getter, femobj_ref, face_masks, edge_masks):
    node_set = []
    result = []
    # TODO get elements from mesh groups
    # if femmesh.GroupCount:
    #     node_set = get_femmesh_groupdata_sets_by_name(femmesh, femobj, "Node")
    #     # FreeCAD.Console.PrintMessage("node_set_group: {}\n".format(node_set))
    #     if node_set:
    #         FreeCAD.Console.PrintLog(
    #             "    Finite element mesh nodes where retrieved "
    #             "from existent finite element mesh group data.\n"
    #         )
    if not node_set:
        sub_elem = []
        FreeCAD.Console.PrintLog(
            "    Finite element mesh nodes will be retrieved "
            "by searching the appropriate nodes in the finite element mesh.\n"
        )
        feat, sub_ref = femobj_ref
        sub = (feat, (sub_ref,))
        node_set = get_femnodes_by_references(sets_getter.femmesh, [sub])
        charged_face_node_set = sorted(set(node_set))

        bit_pattern_dict = get_bit_pattern_dict(
            sets_getter.femelement_table, sets_getter.femnodes_ele_table, charged_face_node_set
        )
        sh = feat.getSubObject(sub_ref)
        if sh.ShapeType == "Face":
            sub_elem = get_element_faces_from_binary_search(bit_pattern_dict, **face_masks)
        elif sh.ShapeType == "Edge":
            sub_elem = get_element_edges_from_binary_search(bit_pattern_dict, **edge_masks)

        result = (sub, sub_elem)

    return result


# ************************************************************************************************
# ***** groups ***********************************************************************************
def get_mesh_group_elements(mesh_group_obj, aPart):
    """the Reference shapes of the mesh_group_object are searched in the Shape of aPart.
    If found in shape they are added to a dict
    {MeshGroupIdentifier : ["ShapeType of the Elements"], [ElementID, ElementID, ...], ...}
    """
    group_elements = {}  # { name : [element, element, ... , element]}
    if mesh_group_obj.References:
        grp_ele = get_reference_group_elements(mesh_group_obj, aPart)
        group_elements[grp_ele[0]] = grp_ele[1]
    else:
        FreeCAD.Console.PrintError(
            "  Empty reference in mesh group object: {} {}\n".format(
                mesh_group_obj.Name, mesh_group_obj.Label
            )
        )
    return group_elements


# ************************************************************************************************
def get_analysis_group_elements(aAnalysis, aPart):
    """
    all Reference shapes of all Analysis member are searched in the Shape of aPart.
    If found in shape they are added to a dict
    {ConstraintName : ["ShapeType of the Elements"], [ElementID, ElementID, ...], ...}
    """
    from femtools.femutils import is_of_type

    group_elements = {}  # { name : [element, element, ... , element]}
    empty_references = []
    # find the objects with empty references, if there are more than one of this type
    # they are for all shapes not in the references of the other objects
    # ATM: empty references if there are more than one obj of this type are allowed for:
    # solid meshes: material
    # face meshes: materials, ShellThickness
    # edge meshes: material, BeamSection/FluidSection
    # BTW: some constraints do have empty references in any case (ex. constraint self weight)
    for m in aAnalysis.Group:
        if hasattr(m, "References"):
            if len(m.References) > 0:
                grp_ele = get_reference_group_elements(m, aPart)
                group_elements[grp_ele[0]] = grp_ele[1]
            elif len(m.References) == 0 and (
                is_of_type(m, "Fem::MaterialCommon")
                # TODO test and implement ElementGeometry1D and ElementGeometry2D
                # or is_of_type(m, "Fem::ElementGeometry1D")
                # or is_of_type(m, "Fem::ElementGeometry2D")
            ):
                FreeCAD.Console.PrintMessage(f"  Empty reference: {m.Name}\n")
                empty_references.append(m)
    if empty_references:
        if len(empty_references) == 1:
            group_elements = get_anlysis_empty_references_group_elements(
                group_elements, aAnalysis, aPart.Shape
            )
        else:
            FreeCAD.Console.PrintError("Problem: more than one object with empty references.\n")
            FreeCAD.Console.PrintMessage(
                "We are going to try to get the empty material references anyway.\n"
            )
            for er in empty_references:
                FreeCAD.Console.PrintMessage(f"{er.Name}\n")
            group_elements = get_anlysis_empty_references_group_elements(
                group_elements, aAnalysis, aPart.Shape
            )
    # check if all groups have at least one element,
    # it doesn"t mean ALL reference shapes for a group have been found
    for g in group_elements:
        # FreeCAD.Console.PrintMessage("{}\n".format(group_elements[g]))
        if len(group_elements[g]) == 0:
            FreeCAD.Console.PrintError(
                "Error: The shapes for the mesh group for the reference "
                "shapes of analysis member: {} could not be found!\n".format(g)
            )
    return group_elements


# ************************************************************************************************
def _get_compound_reference_element(aPart, parent, child, shape_type):
    """Resolve saved compound provenance when source BReps no longer share TShapes.

    Use the native element-history API, not encoded-name parsing or geometric
    ordering. Object IDs are document-local. More than one resulting occurrence
    remains ambiguous and must be selected on the meshed compound explicitly.
    """
    if not aPart.isDerivedFrom("Part::Compound") or parent.Document != aPart.Document:
        return None
    source_parent = parent.getLinkedObject(True) if parent.isDerivedFrom("App::Link") else parent
    source_name = source_parent.Shape.getElementMappedName(child) or child
    occurrence_shape = (sub_shape_at_global_placement(parent, child)
                        if source_parent != parent else None)
    matches = set()
    for indexed in set(aPart.Shape.ElementMap.values()):
        if not indexed.startswith(shape_type):
            continue
        feature, element = aPart, indexed
        visited = set()
        # Walk one native history step at a time. A link can be retagged with its
        # own ID, so unbounded recursive history is not safe for every occurrence.
        while hasattr(feature, "getElementHistory"):
            state = (feature.FullName, element)
            if state in visited:
                break
            visited.add(state)
            history = feature.getElementHistory(element, recursive=False)
            for owner, source, _intermediates in history:
                if owner == source_parent and source == source_name and (
                    occurrence_shape is None or _same_occurrence_geometry(
                        aPart.Shape.getElement(indexed), occurrence_shape)
                ):
                    matches.add(indexed)
            if not history:
                break
            feature, element, _intermediates = history[-1]
    if len(matches) > 1:
        raise ValueError(f"Ambiguous compound reference: matches {', '.join(sorted(matches))}")
    if not matches and source_parent != parent:
        raise ValueError("Unresolved linked occurrence history; select the meshed subelement.")
    return next(iter(matches)) if matches else None


# ************************************************************************************************
def get_reference_group_elements(obj, aPart):
    """obj is an FEM object which has reference shapes like the group object
    the material, most of the constraints
    aPart is geometry feature normally CompSolid
    the method searches all reference shapes of obj inside aPart even if
    the reference shapes are a totally different geometry feature.
    a tuple is returned ("Name or Label of the FEMobject", ["Element1", "Element2", ...])
    The names in the list are the Elements of the geometry aPart
    whereas "Solid1" == aPart.Shape.Solids[0]
    !!! It is strongly recommended to use as reference shapes the Solids of a CompSolid
    and not the Solids the CompSolid is made of !!!
    see https://forum.freecad.org/viewtopic.php?f=18&t=12212&p=175777#p175777
    and following posts
    Occt might change the Solids a CompSolid is made of during
    creation of the CompSolid by adding Edges and vertices
    Thus the Elements do not have the same geometry anymore
    """
    aShape = aPart.Shape
    if hasattr(obj, "UseLabel") and obj.UseLabel:
        # TODO: check the character of the Label
        # only allow underline and standard english character
        key = obj.Label
    else:
        key = obj.Name
    elements = []
    for r in obj.References:
        parent = r[0]
        childs = r[1]
        # FreeCAD.Console.PrintMessage("{}\n".format(parent))
        # FreeCAD.Console.PrintMessage("{}\n".format(childs))

        for child1 in childs:
            ref_shape1 = parent.getSubObject(child1)
            # An explicit index on the meshed object already carries ownership.
            # Do not replace it with the first geometrically coincident element.
            shape_type = ref_shape1.ShapeType
            if (parent == aPart and shape_type in ("Solid", "Face", "Edge", "Vertex")
                    and child1.startswith(shape_type)
                    and child1[len(shape_type):].isdigit()):
                elements.append(child1)
                continue
            if shape_type in ("Face", "Edge", "Vertex"):
                try:
                    found_element = _get_compound_reference_element(
                        aPart, parent, child1, shape_type)
                except ValueError as error:
                    raise ValueError(
                        f"{obj.Name}: reference {parent.Name}.{child1} in {aPart.Name}: {error}"
                    ) from error
                if found_element:
                    elements.append(found_element)
                    continue
            subchilds = [
                ref_shape1,
            ]
            if (
                ref_shape1.ShapeType == "Compound"
            ):  # if user selects a compound, add all the solids in it
                subchilds = ref_shape1.Solids
            for ref_shape in subchilds:
                FreeCAD.Console.PrintLog(f"{ref_shape}\n")
                try:
                    found_element = geomtools.find_element_in_shape(aShape, ref_shape)
                except ValueError as error:
                    raise ValueError(
                        f"{obj.Name}: reference {parent.Name}.{child1} in {aPart.Name}: {error}"
                    ) from error
                if found_element is not None:
                    elements.append(found_element)
                else:
                    FreeCAD.Console.PrintError(
                        "Problem: For the geometry of the "
                        "following shape was no Shape found: {}\n".format(ref_shape)
                    )
                    FreeCAD.Console.PrintMessage("    " + obj.Name + "\n")
                    FreeCAD.Console.PrintMessage("    " + str(obj.References) + "\n")
                    FreeCAD.Console.PrintMessage("    " + r[0].Name + "\n")
                    if parent.Name != aPart.Name:
                        FreeCAD.Console.PrintError(
                            "The reference Shape is not a child "
                            "nor it is the shape the mesh is made of. : {}\n".format(ref_shape)
                        )
                        FreeCAD.Console.PrintMessage(
                            f"{aPart.Name}--> Name of the Feature we where searching in.\n"
                        )
                        FreeCAD.Console.PrintMessage(
                            "{} --> Name of the parent Feature of reference Shape "
                            "(Use the same as in the line before and you "
                            "will have less trouble :-) !!!!!!).\n".format(parent.Name)
                        )
                        # import Part
                        # Part.show(aShape)
                        # Part.show(ref_shape)
                    else:
                        FreeCAD.Console.PrintError("This should not happen, please debug!\n")
                        # in this case we would not have needed to use the
                        # is_same_geometry() inside geomtools.find_element_in_shape()
                        # AFAIK we could have used the Part methods isPartner() or even isSame()
                        # We're going to find out when we need to debug this :-)!
    return (key, sorted(elements))


# ************************************************************************************************
def get_anlysis_empty_references_group_elements(group_elements, aAnalysis, aShape):
    """
    get the elementIDs if the Reference shape is empty
    see get_analysis_group_elements() for more information
    """
    # FreeCAD.Console.PrintMessage("{}\n".format(group_elements))
    material_ref_shapes = []
    material_shape_type = ""
    missed_material_refshapes = []
    empty_reference_material = None
    for m in aAnalysis.Group:
        if m.isDerivedFrom("App::MaterialObjectPython"):
            if hasattr(m, "References") and not m.References:
                if not empty_reference_material:
                    empty_reference_material = m.Name
                else:
                    FreeCAD.Console.PrintError(
                        "Problem in get_anlysis_empty_references_group_elements, "
                        "we seem to have two or more materials with empty references\n"
                    )
                    return {}
            elif hasattr(m, "References") and m.References:
                # ShapeType of the group elements, strip the number of the first group element
                # http://stackoverflow.com/questions/12851791/removing-numbers-from-string
                group_shape_type = "".join(i for i in group_elements[m.Name][0] if not i.isdigit())
                if not material_shape_type:
                    material_shape_type = group_shape_type
                elif material_shape_type != group_shape_type:
                    FreeCAD.Console.PrintError(
                        "Problem, material shape type does not match "
                        "get_anlysis_empty_references_group_elements\n"
                    )
                for ele in group_elements[m.Name]:
                    material_ref_shapes.append(ele)
    if material_shape_type == "Solid":
        # FreeCAD.Console.PrintMessage("{}\n".format(len(aShape.Solids)))
        for i in range(len(aShape.Solids)):
            ele = "Solid" + str(i + 1)
            if ele not in material_ref_shapes:
                missed_material_refshapes.append(ele)
    elif material_shape_type == "Face":
        # FreeCAD.Console.PrintMessage("{}\n".format(len(aShape.Faces)))
        for i in range(len(aShape.Faces)):
            ele = "Face" + str(i + 1)
            if ele not in material_ref_shapes:
                missed_material_refshapes.append(ele)
    elif material_shape_type == "Edge":
        # FreeCAD.Console.PrintMessage("{}\n".format(len(aShape.Edges)))
        for i in range(len(aShape.Edges)):
            ele = "Edge" + str(i + 1)
            if ele not in material_ref_shapes:
                missed_material_refshapes.append(ele)
    else:
        FreeCAD.Console.PrintMessage(
            "  One material with no reference shapes. No need to make a group for materials.\n"
        )
        # make no changes group_elements
        return group_elements
    # FreeCAD.Console.PrintMessage("{}\n".format(sorted(material_ref_shapes)))
    # FreeCAD.Console.PrintMessage("{}\n".format(sorted(missed_material_refshapes)))
    # FreeCAD.Console.PrintMessage(group_elements)
    group_elements[empty_reference_material] = sorted(missed_material_refshapes)
    # FreeCAD.Console.PrintMessage("{}\n".format(group_elements))
    return group_elements


# ************************************************************************************************
def femelements_count_ok(len_femelement_table, count_femelements):
    FreeCAD.Console.PrintMessage(
        f"Count finite elements as sum of constraints:   {count_femelements}\n"
    )
    FreeCAD.Console.PrintMessage(
        f"Count finite elements of the finite element mesh: {len_femelement_table}\n"
    )
    if count_femelements == len_femelement_table:
        return True
    else:
        FreeCAD.Console.PrintMessage("ERROR: femelement_table != count_femelements\n")
        return False


# ************************************************************************************************
def delete_duplicate_mesh_elements(refelement_table):
    new_refelement_table = {}  # duplicates deleted
    for elem, nodes in refelement_table.items():
        if sorted(nodes) not in sortlistoflistvalues(new_refelement_table.values()):
            new_refelement_table[elem] = nodes
    return new_refelement_table


# ************************************************************************************************
def get_triangle_area(P1, P2, P3):
    # import Part
    # W = Part.Wire([Part.makeLine(P1,P2), Part.makeLine(P2,P3), Part.makeLine(P3,P1)])
    # Part.show(Part.Face(W))
    vec1 = P2 - P1
    vec2 = P3 - P1
    vec3 = vec1.cross(vec2)
    return 0.5 * vec3.Length


# ************************************************************************************************
def sortlistoflistvalues(listoflists):
    new_list = []
    for li in listoflists:
        new_list.append(sorted(li))
    return new_list


# ************************************************************************************************
def is_solid_femmesh(femmesh):
    # solid femmesh
    if femmesh.VolumeCount > 0:
        return True


# ************************************************************************************************
def has_no_face_data(femmesh):
    # femmesh has no face data, could be a edge femmesh or a solid femmesh without face data
    if femmesh.FaceCount == 0:
        return True


# ************************************************************************************************
def is_face_femmesh(femmesh):
    # face femmesh
    if femmesh.VolumeCount == 0 and femmesh.FaceCount > 0:
        return True


# ************************************************************************************************
def is_edge_femmesh(femmesh):
    # edge femmesh
    if femmesh.VolumeCount == 0 and femmesh.FaceCount == 0 and femmesh.EdgeCount > 0:
        return True


# ************************************************************************************************
def is_zplane_2D_mesh(femmesh):
    # used in oofem writer to distinguish between 3D and 2D plane stress
    if is_face_femmesh(femmesh) is True:
        tol = 0.0001
        for n in femmesh.Nodes:
            z = femmesh.Nodes[n].z
            if ((0 - tol) < z < (0 + tol)) is not True:
                return False
        return True
    else:
        return False


# ************************************************************************************************
def get_femmesh_eletype(femmesh, femelement_table=None):
    if not femmesh:
        FreeCAD.Console.PrintError("Error: No femmesh.\n")
    if not femelement_table:
        FreeCAD.Console.PrintWarning("The femelement_table needs to be calculated.\n")
        femelement_table = get_femelement_table(femmesh)
    # in some cases lowest key in femelement_table is not [1]
    for elem in sorted(femelement_table):
        elem_length = len(femelement_table[elem])
        FreeCAD.Console.PrintLog(f"Node count of first element: {elem_length}\n")
        break  # break after the first elem
    if is_solid_femmesh(femmesh):
        if femmesh.TetraCount == femmesh.VolumeCount:
            if elem_length == 4:
                return "tetra4"
            elif elem_length == 10:
                return "tetra10"
            else:
                FreeCAD.Console.PrintMessage("Tetra with neither 4 nor 10 nodes.\n")
                return "None"
        elif femmesh.HexaCount == femmesh.VolumeCount:
            if elem_length == 8:
                return "hexa8"
            elif elem_length == 20:
                return "hexa20"
            else:
                FreeCAD.Console.PrintError("Hexa with neither 8 nor 20 nodes.\n")
                return "None"
        else:
            FreeCAD.Console.PrintError("no tetra, no hexa or Mixed Volume Elements.\n")
    elif is_face_femmesh(femmesh):
        if femmesh.TriangleCount == femmesh.FaceCount:
            if elem_length == 3:
                return "tria3"
            elif elem_length == 6:
                return "tria6"
            else:
                FreeCAD.Console.PrintError("Tria with neither 3 nor 6 nodes.\n")
                return "None"
        elif femmesh.QuadrangleCount == femmesh.FaceCount:
            if elem_length == 4:
                return "quad4"
            elif elem_length == 8:
                return "quad8"
            else:
                FreeCAD.Console.PrintError("Quad with neither 4 nor 8 nodes.\n")
                return "None"
        else:
            FreeCAD.Console.PrintError("no tria, no quad\n")
            return "None"
    elif is_edge_femmesh(femmesh):
        if elem_length == 2:
            return "seg2"
        elif elem_length == 3:
            return "seg3"
        else:
            FreeCAD.Console.PrintError("Seg with neither 2 nor 3 nodes.\n")
            return "None"
    else:
        FreeCAD.Console.PrintError("Neither edge nor face nor solid femmesh.\n")
        return "None"
    return "None"


# ************************************************************************************************
def get_three_non_colinear_nodes(nodes_coords):
    # Code to obtain three non-colinear nodes on the PlaneRotation support face
    # nodes_coords --> [(nodenumber, x, y, z), (nodenumber, x, y, z), ...]
    if not nodes_coords:
        FreeCAD.Console.PrintMessage(f"{len(nodes_coords)}\n")
        FreeCAD.Console.PrintMessage("Error: No nodes in nodes_coords\n")
        return []
    dum_max = [1, 2, 3, 4, 5, 6, 7, 8, 0]
    for i in range(len(nodes_coords)):
        for j in range(len(nodes_coords) - 1 - i):
            x_1 = nodes_coords[j][1]
            x_2 = nodes_coords[j + 1][1]
            y_1 = nodes_coords[j][2]
            y_2 = nodes_coords[j + 1][2]
            z_1 = nodes_coords[j][3]
            z_2 = nodes_coords[j + 1][3]
            node_1 = nodes_coords[j][0]
            node_2 = nodes_coords[j + 1][0]
            distance = ((x_1 - x_2) ** 2 + (y_1 - y_2) ** 2 + (z_1 - z_2) ** 2) ** 0.5
            if distance > dum_max[8]:
                dum_max = [node_1, x_1, y_1, z_1, node_2, x_2, y_2, z_2, distance]
    node_dis = [1, 0]
    for i in range(len(nodes_coords)):
        x_1 = dum_max[1]
        x_2 = dum_max[5]
        x_3 = nodes_coords[i][1]
        y_1 = dum_max[2]
        y_2 = dum_max[6]
        y_3 = nodes_coords[i][2]
        z_1 = dum_max[3]
        z_2 = dum_max[7]
        z_3 = nodes_coords[i][3]
        node_3 = int(nodes_coords[j][0])
        distance_1 = ((x_1 - x_3) ** 2 + (y_1 - y_3) ** 2 + (z_1 - z_3) ** 2) ** 0.5
        distance_2 = ((x_3 - x_2) ** 2 + (y_3 - y_2) ** 2 + (z_3 - z_2) ** 2) ** 0.5
        tot = distance_1 + distance_2
        if tot > node_dis[1]:
            node_dis = [node_3, tot]
    node_1 = int(dum_max[0])
    node_2 = int(dum_max[4])
    FreeCAD.Console.PrintMessage(f"{[node_1, node_2, node_3]}\n")
    return [node_1, node_2, node_3]


# ************************************************************************************************
def use_correct_fluidinout_ele_def(FluidInletoutlet_ele, fileName, fluid_inout_nodes_file):
    f = open(fileName)
    cnt = 0
    line = f.readline()

    # start reading from *ELEMENT
    while line.find("Element") == -1:
        line = f.readline()
        cnt = cnt + 1
    line = f.readline()
    cnt = cnt + 1

    # obtain element line numbers for inlet and outlet
    while len(line) > 1:
        ind = line.find(",")
        elem = line[0:ind]
        for i in range(len(FluidInletoutlet_ele)):
            if elem == FluidInletoutlet_ele[i][0]:
                FluidInletoutlet_ele[i][2] = cnt
        line = f.readline()
        cnt = cnt + 1
    f.close()

    # re-define elements for INLET and OUTLET
    f = open(fileName, "r+")
    lines = f.readlines()
    f.seek(0)
    cnt = 0
    elem_counter = 0
    FreeCAD.Console.PrintMessage(f"1DFlow inout nodes file: {fluid_inout_nodes_file}\n")
    inout_nodes_file = open(fluid_inout_nodes_file, "w")
    for line in lines:
        new_line = ""
        for i in range(len(FluidInletoutlet_ele)):
            if cnt == FluidInletoutlet_ele[i][2]:
                elem_counter = elem_counter + 1
                a = line.split(",")
                for j in range(len(a)):
                    if elem_counter == 1:
                        if j == 1:
                            new_line = new_line + " 0,"
                            node1 = int(a[j + 2])
                            node2 = int(a[j + 1])
                            node3 = int(a[j])
                            inout_nodes_file.write(
                                "{},{},{},{}\n".format(
                                    node1, node2, node3, FluidInletoutlet_ele[i][1]
                                )
                            )
                        elif j == 3:
                            new_line = new_line + a[j]
                        else:
                            new_line = new_line + a[j] + ","
                    else:
                        if j == 3:
                            new_line = new_line + " 0\n"
                            node1 = int(a[j - 2])
                            node2 = int(a[j - 1])
                            node3 = int(a[j])
                            inout_nodes_file.write(
                                "{},{},{},{}\n".format(
                                    node1, node2, node3, FluidInletoutlet_ele[i][1]
                                )
                            )
                        else:
                            new_line = new_line + a[j] + ","
        if new_line == "":
            f.write(line)
        else:
            f.write(new_line)
        cnt = cnt + 1
    f.truncate()
    f.close()
    inout_nodes_file.close()


# ************************************************************************************************
def compact_mesh(old_femmesh):
    """
    removes all gaps in node and element ids, start ids with 1
    returns a tuple (FemMesh, node_assignment_map, element_assignment_map)
    """
    node_map = {}  # {old_node_id: new_node_id, ...}
    elem_map = {}  # {old_elem_id: new_elem_id, ...}
    old_nodes = old_femmesh.Nodes
    import Fem

    new_mesh = Fem.FemMesh()

    if old_nodes:
        for i, n in enumerate(old_nodes):
            nid = i + 1
            new_mesh.addNode(old_nodes[n].x, old_nodes[n].y, old_nodes[n].z, nid)
            node_map[n] = nid

    # element id is one id for Edges, Faces and Volumes
    # thus should not start with 0 for each element type
    # because this will give an error for mixed meshes
    # because the id is used already
    # https://forum.freecad.org/viewtopic.php?t=48215
    ele_id = 1
    if old_femmesh.Edges:
        for ed in old_femmesh.Edges:
            old_elem_nodes = old_femmesh.getElementNodes(ed)
            new_elemnodes = []
            for old_node_id in old_elem_nodes:
                new_elemnodes.append(node_map[old_node_id])
            new_mesh.addEdge(new_elemnodes, ele_id)
            elem_map[ed] = ele_id
            ele_id += 1
    if old_femmesh.Faces:
        for fa in old_femmesh.Faces:
            ele_id += 1
            old_elem_nodes = old_femmesh.getElementNodes(fa)
            new_elemnodes = []
            for old_node_id in old_elem_nodes:
                new_elemnodes.append(node_map[old_node_id])
            new_mesh.addFace(new_elemnodes, ele_id)
            elem_map[fa] = ele_id
            ele_id += 1
    if old_femmesh.Volumes:
        for vo in old_femmesh.Volumes:
            old_elem_nodes = old_femmesh.getElementNodes(vo)
            new_elemnodes = []
            for old_node_id in old_elem_nodes:
                new_elemnodes.append(node_map[old_node_id])
            new_mesh.addVolume(new_elemnodes, ele_id)
            elem_map[vo] = ele_id
            ele_id += 1

    # may be return another value if the mesh was compacted, just check last map entries
    return (new_mesh, node_map, elem_map)


# ************************************************************************************************
def sub_shape_at_global_placement(obj, sub_name):
    sub_sh = obj.getSubObject(sub_name)
    # get partner shape
    partner = sub_sh.transformed(FreeCAD.Placement().Matrix)
    if hasattr(obj, "getGlobalPlacement"):
        placement = obj.getGlobalPlacement()
    else:
        # App::Link already applies its occurrence placement in getSubObject,
        # but does not expose GeoFeature's getGlobalPlacement Python method.
        placement = obj.Placement
        parent = obj.getParentGeoFeatureGroup()
        while parent:
            placement = parent.Placement * placement
            parent = parent.getParentGeoFeatureGroup()
    partner.Placement = placement * obj.Placement.inverse() * sub_sh.Placement

    return partner


##  @}
