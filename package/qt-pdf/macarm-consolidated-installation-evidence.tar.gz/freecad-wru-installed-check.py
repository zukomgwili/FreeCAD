import hashlib
import json
from pathlib import Path
import unittest
import FreeCAD
import ArchSite
from bimtests.TestArchSite import TestArchSite

origin = Path(ArchSite.__file__).resolve()
assert 'freecad-wru-stage' in str(origin) or str(origin).startswith('/Applications/FreeCAD-27.1.0.app/')
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(TestArchSite))
report = {'version': FreeCAD.Version(), 'archsite_origin': str(origin),
          'archsite_sha256': hashlib.sha256(origin.read_bytes()).hexdigest(),
          'tests_run': result.testsRun, 'passed': result.wasSuccessful(),
          'failures': [(str(t), s) for t, s in result.failures],
          'errors': [(str(t), s) for t, s in result.errors]}
Path('/private/tmp/freecad-wru-installed-check.json').write_text(json.dumps(report, indent=2) + '\n')
assert result.testsRun == 6 and result.wasSuccessful()
import Part
import Spreadsheet
doc = FreeCAD.newDocument('InstalledSheetRegression')
sheet = doc.addObject('Spreadsheet::Sheet', 'Inputs')
sheet.set('B1', '2700')
sheet.setAlias('B1', 'WallHeight')
box = doc.addObject('Part::Box', 'Wall')
box.setExpression('Height', 'Inputs.WallHeight * 1 mm')
doc.recompute()
assert box.Height.Value == 2700
doc.saveAs('/private/tmp/freecad-wru-sheet.FCStd')
FreeCAD.closeDocument(doc.Name)
doc = FreeCAD.openDocument('/private/tmp/freecad-wru-sheet.FCStd')
doc.Inputs.set('B1', '2900')
doc.recompute()
assert doc.Wall.Height.Value == 2900, doc.Wall.Height
assert abs(doc.Wall.Shape.BoundBox.ZLength - 2900) < 1e-6
FreeCAD.closeDocument(doc.Name)
report['spreadsheet_reopened_dependency_passed'] = True
Path('/private/tmp/freecad-wru-installed-check.json').write_text(json.dumps(report, indent=2) + '\n')
