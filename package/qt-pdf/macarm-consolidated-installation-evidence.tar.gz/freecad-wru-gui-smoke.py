import ctypes
import json
from pathlib import Path
import FreeCAD as App
import FreeCADGui as Gui
import Part
import TechDraw
import TechDrawGui
from PySide6 import QtCore, QtWidgets

assert App.Version()[-1] == '93340a47b4c1f79b2ac32b704e45e5a21706b72c'
assert App.getResourceDir().startswith('/Applications/FreeCAD-27.1.0.app/')
doc = App.getDocument('InstalledTechDrawCheck') if 'InstalledTechDrawCheck' in App.listDocuments() else App.newDocument('InstalledTechDrawCheck')
box = doc.getObject('Box') or doc.addObject('Part::Box', 'Box')
box.Length, box.Width, box.Height = 40, 30, 20
page = doc.getObject('Page') or doc.addObject('TechDraw::DrawPage', 'Page')
template = doc.getObject('Template') or doc.addObject('TechDraw::DrawSVGTemplate', 'Template')
template.Template = App.getResourceDir() + 'Mod/TechDraw/Templates/Default_Template_A4_Landscape.svg'
page.Template = template
view = doc.addObject('TechDraw::DrawViewPart', 'View')
view.Source = [box]
view.Direction = App.Vector(0, 0, 1)
page.addView(view)
doc.recompute()
Gui.activeDocument().activeView().viewAxonometric()
Gui.activeDocument().activeView().fitAll()
Gui.activeDocument().getObject(page.Name).show()
loop = QtCore.QEventLoop()
QtCore.QTimer.singleShot(1500, loop.quit)
loop.exec()
TechDrawGui.exportPageAsPdf(page, '/private/tmp/freecad-wru-stock-techdraw.pdf')
doc.saveAs('/private/tmp/freecad-wru-stock-techdraw.FCStd')
native = ctypes.CDLL(None)
native._dyld_image_count.restype = ctypes.c_uint32
native._dyld_get_image_name.argtypes = [ctypes.c_uint32]
native._dyld_get_image_name.restype = ctypes.c_char_p
images = [native._dyld_get_image_name(i).decode() for i in range(native._dyld_image_count())]
cocoa = [p for p in images if p.endswith('/libqcocoa.dylib')]
assert cocoa == ['/Users/zukomgwili/src/FreeCAD/.pixi/envs/default/lib/qt6/plugins/platforms/libqcocoa.dylib'], cocoa
report = {'version': App.Version(), 'resource_dir': App.getResourceDir(), 'cocoa_images': cocoa,
          'qt_version': QtCore.qVersion(), 'platform': QtWidgets.QApplication.platformName(),
          'pdf_bytes': Path('/private/tmp/freecad-wru-stock-techdraw.pdf').stat().st_size,
          'passed': True}
assert report['pdf_bytes'] > 1000
Path('/private/tmp/freecad-wru-gui-smoke.json').write_text(json.dumps(report, indent=2) + '\n')
print('Installed GUI, packaged Cocoa and stock TechDraw PDF checks passed')
