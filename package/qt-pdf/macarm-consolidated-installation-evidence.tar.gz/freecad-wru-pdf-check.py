import importlib.util
import json
from pathlib import Path
import shutil

spec = importlib.util.spec_from_file_location('pdfcheck', '/Users/zukomgwili/src/FreeCAD/tests/src/Mod/TechDraw/Gui/QtPdfStroker/compare.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
report = module.compare(Path('/private/tmp/freecad-4fa-pdf-qualification-v2/generated/patched'), Path('/private/tmp/freecad-wru-pdf-generated'), shutil.which('pdftoppm'))
ignored = [s for s in report['failures'] if ': baseline: expected ' in s or s in {
    'No baseline case reproduced both invalid close and Poppler warning',
    'qpdfwriter: no baseline defect was reproduced',
    'qprinter: no baseline defect was reproduced'}]
failures = [s for s in report['failures'] if s not in ignored]
assert len(report['cases']) == 66
assert not failures, failures
assert all(c['same_pixels'] and c['same_coordinates'] and c['same_normalized_operations'] for c in report['cases'])
report.update(scope='Build-2 installed runtime regression parity against previously fixed candidate, not original baseline reproduction', ignored_fixed_baseline_expectations=ignored, regression_failures=failures, regression_passed=True)
Path('/private/tmp/freecad-wru-pdf-check.json').write_text(json.dumps(report, indent=2) + '\n')
print('66 PDF cases passed geometry, raster and operator parity')
