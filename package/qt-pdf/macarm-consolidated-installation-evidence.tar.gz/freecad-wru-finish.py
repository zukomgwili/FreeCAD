import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path('/private/tmp/freecad-wru-stage/FreeCAD-27.1.0.app')
old = Path('/Applications/FreeCAD-27.1.0.app')
source = Path('/Users/zukomgwili/src/FreeCAD')
prefix = source / '.pixi/envs/default'
launcher = Path('/private/var/folders/9b/px5x12_n00s4mt10fk4sh6nr0000gn/T/freecad-build-install-mc3_gfhv/FreeCADLocalLauncher.c')
assert root.is_dir() and not root.is_symlink()
assert (root / 'Contents/Resources/Mod/BIM/ArchSite.py').is_file()
for name in ('Info.plist', 'PkgInfo'):
    shutil.copy2(old / 'Contents' / name, root / 'Contents' / name)
macos = root / 'Contents/MacOS'
macos.mkdir(exist_ok=True)
sdk = subprocess.check_output(['xcrun', '--show-sdk-path'], text=True).strip()
for name in ('FreeCAD', 'FreeCADCmd'):
    subprocess.run(['xcrun', 'clang', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                    '-arch', 'arm64', '-isysroot', sdk,
                    '-DAPP_DEPENDENCY_PREFIX=' + json.dumps(str(prefix)),
                    '-DAPP_BINARY_NAME=' + json.dumps(name), str(launcher),
                    '-o', str(macos / name)], check=True)
for name in ('freecad.icns', 'freecad-doc.icns', 'freecad-script.icns'):
    shutil.copy2(old / 'Contents/Resources' / name, root / 'Contents/Resources' / name)
magics = {bytes.fromhex(s) for s in ('feedface', 'cefaedfe', 'feedfacf', 'cffaedfe', 'cafebabe', 'bebafeca', 'cafebabf', 'bfbafeca')}
signed = []
for path in root.rglob('*'):
    if path.is_file() and not path.is_symlink():
        with path.open('rb') as stream:
            magic = stream.read(4)
        if magic in magics:
            subprocess.run(['codesign', '--force', '--sign', '-', str(path)], check=True)
            signed.append(str(path.relative_to(root)))
for path in sorted(root.rglob('*.appex'), reverse=True):
    subprocess.run(['codesign', '--force', '--sign', '-', str(path)], check=True)
subprocess.run(['codesign', '--force', '--sign', '-', str(root)], check=True)
subprocess.run(['codesign', '--verify', '--deep', '--strict', str(root)], check=True)
receipt = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip(),
           'staged_app': str(root), 'dependency_prefix': str(prefix), 'signed_macho': signed,
           'relocatable': False, 'signature_verified': True,
           'archsite_sha256': hashlib.sha256((root / 'Contents/Resources/Mod/BIM/ArchSite.py').read_bytes()).hexdigest()}
Path('/private/tmp/freecad-wru-staging.json').write_text(json.dumps(receipt, indent=2) + '\n')
